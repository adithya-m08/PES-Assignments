insert into user
values(1, 'address1', 1234567890, '2019-12-31', 11);

insert into user
values(2, 'address2', 3948394334, '2020-10-1', 22);

insert into user
values(3, 'address3', 4442432343, '2013-3-3', 33);

insert into user
values(4, 'address4', 4434324324, '2001-4-3', 44);

insert into user
values(5, 'address5', 1234567890, '2009-2-2', 55);

insert into user
values(6, 'address6', 3948394334, '2010-1-3', 66);

insert into user
values(7, 'address7', 4442432343, '2011-4-5', 77);

insert into user
values(8, 'address8', 4434324324, '2012-5-6', 88);

insert into user
values(9, 'address9', 1234567890, '2013-6-7', 99);

insert into user
values(10, 'address10', 3948394334, '2014-7-8', 100);

insert into user
values(11, 'address11', 4442432343, '2015-8-9', 111);

insert into user
values(12, 'address12', 4434324324, '2016-9-10', 122);

insert into user
values(13, 'address13', 1234567890, '2017-10-11', 133);

insert into user
values(14, 'address14', 3948394334, '2018-11-12', 144);

insert into user
values(15, 'address15', 4442432343, '2019-12-13', 155);

insert into borrow
values(11, 1, 111, '2022-2-2', 100);

insert into borrow
values(22, 2, 222, '2030-1-3', 200);

insert into borrow
values(33, 3, 333, '2021-4-5', 300);

insert into borrow
values(44, 4, 444, '2020-5-6', 400);

insert into borrow
values(55, 5, 111, '2022-2-2', 100);

insert into borrow
values(66, 6, 222, '2030-1-3', 200);

insert into borrow
values(77, 7, 333, '2021-4-5', 300);

insert into borrow
values(88, 8, 444, '2020-5-6', 400);

insert into borrow
values(99, 9, 111, '2022-2-2', 100);

insert into borrow
values(100, 10, 222, '2030-1-3', 200);

insert into borrow
values(111, 11, 333, '2021-4-5', 300);

insert into borrow
values(122, 12, 444, '2020-5-6', 400);

insert into borrow
values(133, 13, 111, '2022-2-2', 100);

insert into borrow
values(144, 14, 222, '2030-1-3', 200);

insert into borrow
values(155, 15, 333, '2021-4-5', 300);

insert into books
values(111, 'title1', 'author1', 100, '2019-12-31', 1111);

insert into books
values(222, 'title2', 'author2', 200, '2020-10-1', 2222);

insert into books
values(333, 'title3', 'author3', 300, '2013-3-3', 3333);

insert into books
values(444, 'title4', 'author4', 400, '2001-4-3', 4444);

insert into books
values(555, 'title5', 'author5', 500, '2009-2-2', 1111);

insert into books
values(666, 'title6', 'author6', 600, '2010-1-3', 2222);

insert into books
values(777, 'title7', 'author7', 700, '2011-4-5', 3333);

insert into books
values(888, 'title8', 'author8', 800, '2012-5-6', 4444);

insert into books
values(999, 'title9', 'author9', 900, '2013-6-7', 1111);

insert into books
values(1000, 'title10', 'author10', 1000, '2014-7-8', 2222);

insert into books
values(1111, 'title11', 'author11', 1100, '2015-8-9', 3333);

insert into books
values(1222, 'title12', 'author12', 1200, '2016-9-10', 4444);

insert into books
values(1333, 'title13', 'author13', 1300, '2017-10-11', 1111);

insert into books
values(1444, 'title14', 'author14', 1400, '2018-11-12', 2222);

insert into books
values(1555, 'title15', 'author15', 1500, '2019-12-13', 3333);

insert into category
values(1111, 'name1', 11111);

insert into category
values(2222, 'name2', 22222);

insert into category
values(3333, 'name3', 33333);

insert into category
values(4444, 'name4', 44444);

insert into category
values(5555, 'name5', 55555);

insert into category
values(6666, 'name6', 66666);

insert into category
values(7777, 'name7', 77777);

insert into category
values(8888, 'name8', 88888);

insert into category
values(9999, 'name9', 99999);

insert into category
values(10000, 'name10', 100000);

insert into category
values(11111, 'name11', 111111);

insert into category
values(12222, 'name12', 122222);

insert into category
values(13333, 'name13', 133333);

insert into category
values(14444, 'name14', 144444);

insert into category
values(15555, 'name15', 155555);

insert into returns
values(111, 11, '2022-2-2', 100, 'remarks1');

insert into returns
values(222, 22, '2030-1-3', 200, 'remarks2');

insert into returns
values(333, 33, '2021-4-5', 300, 'remarks3');

insert into returns
values(444, 44, '2020-5-6', 400, 'remarks4');

insert into returns
values(555, 55, '2022-2-2', 100, 'remarks5');

insert into returns
values(666, 66, '2030-1-3', 200, 'remarks6');

insert into returns
values(777, 77, '2021-4-5', 300, 'remarks7');

insert into returns
values(888, 88, '2020-5-6', 400, 'remarks8');

insert into returns
values(999, 99, '2022-2-2', 100, 'remarks9');

insert into returns
values(1000, 100, '2030-1-3', 200, 'remarks10');

insert into returns
values(1111, 111, '2021-4-5', 300, 'remarks11');

insert into returns
values(1222, 122, '2020-5-6', 400, 'remarks12');

insert into returns
values(1333, 133, '2022-2-2', 100, 'remarks13');

insert into returns
values(1444, 144, '2030-1-3', 200, 'remarks14');

insert into returns
values(1555, 155, '2021-4-5', 300, 'remarks15');