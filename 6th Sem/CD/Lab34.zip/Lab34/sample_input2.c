int main()
{
	float x;
	int y;
	x = 3.4;
	y = 45.4;
	if(5>6)
	{
		x=4.5;
	}
	else
	{
		int z=5*6+5;
	}
}
