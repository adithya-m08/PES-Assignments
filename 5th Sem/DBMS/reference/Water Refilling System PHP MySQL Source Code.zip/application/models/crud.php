<?php

    class Crud extends CI_Model
    {
        function __construct()
        {
            parent::__construct();
        }

        function getData($table, $condition)
        {
            $query = $this->db->query("SELECT * FROM $table WHERE $condition");

            $result['total'] = $query->num_rows();
            $result['rows'] = $query->result();

            return $result;
        }

        function addData($table, $data)
        {
            $add = $this->db->insert($table, $data);
            $result['ret_id'] = $this->db->insert_id();
            $result['success'] = $add;
            return $result;
        }

        function addBatchData($table, $data)
        {
            $add = $this->db->insert_batch($table, $data);
            
            return $add;
        }

        function editData($primarykey, $id, $table, $data)
        {
            $this->db->where($primarykey, $id);
            $query = $this->db->update($table, $data); 
            
            return $query;
        }

        function deleteData($table, $condition)
        {
            $query = $this->db->query("DELETE FROM $table WHERE $condition");

            return $query;
        }
    }

?>