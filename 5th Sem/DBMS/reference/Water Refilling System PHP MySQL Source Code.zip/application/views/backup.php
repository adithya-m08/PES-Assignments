<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb push-down-0">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <!-- START CONTENT FRAME -->
                    <div class="content-frame">
                        
                        <!-- START CONTENT FRAME TOP -->
                        <div class="content-frame-top">                        
                            <div class="page-title">                    
                                <h2><span class="fa fa-dropbox"></span> Database Backup</h2>
                            </div>                                      
                            <div class="pull-right">
                                <button class="btn btn-default content-frame-left-toggle"><span class="fa fa-bars"></span></button>
                            </div>                        
                        </div>
                        <!-- END CONTENT FRAME TOP -->
                        
                        <!-- START CONTENT FRAME RIGHT -->
                        <div class="content-frame-right">
                            
                            <form method="POST">
                                <table class="table-condensed" width="100%">
                                    <tr>
                                        <td>
                                            <h3>CREATE BACK UP</h3>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <button class="btn btn-default" type="button" onclick="createBackup()"><i class="fa fa-download"></i> BACK UP</button>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                           
                        </div>
                        <!-- END CONTENT FRAME RIGHT -->
                        
                        <!-- START CONTENT FRAME BODY -->
                        <div class="content-frame-body content-frame-body-left">
                            
                            <?php $query = $codeblooded->crud->getData("tbl_database_backups", "1 ORDER BY dbb_date desc"); ?>

                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <table id="backupdatabase-table" class="table-condensed" width="100%">
                                        <thead>
                                            <tr>
                                                <td style="border-bottom:2px solid #111"><b>DATE</b></td>
                                                <td style="border-bottom:2px solid #111"><b>FILE</b></td>
                                                <td style="border-bottom:2px solid #111"><b>SIZE</b></td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                         <?php if ($query['total'] != 0): ?>
                                            <?php foreach ($query['rows'] as $key): ?>
                                            <tr>
                                                <td><?php echo date("m/d/Y - h:iA", strtotime($key->dbb_date)) ?></td>
                                                <td><a href="assets/database_backup/<?php echo $key->dbb_file ?>"><?php echo $key->dbb_file ?></a></td>
                                                <td><?php echo filesize_formatted("assets/database_backup/$key->dbb_file") ?></td>
                                            </tr>  
                                            <?php endforeach ?>
                                        <?php endif ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td style="border-bottom:2px solid #111"></td>
                                                <td style="border-bottom:2px solid #111"></td>
                                                <td style="border-bottom:2px solid #111"></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>

                            <?php 
                                function filesize_formatted($path)
                                {
                                    $size = filesize($path);
                                    $units = array( 'B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
                                    $power = $size > 0 ? floor(log($size, 1024)) : 0;
                                    return number_format($size / pow(1024, $power), 2, '.', ',') . ' ' . $units[$power];
                                }
                            ?>

                        </div>
                        <!-- END CONTENT FRAME BODY -->
                    </div>
                    <!-- END CONTENT FRAME -->

            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <?php include "shared/js.php"; ?>

        <script type="text/javascript" src="assets/js/plugins/morris/raphael-min.js"></script>
        <script type="text/javascript" src="assets/js/plugins/morris/morris.min.js"></script>

        <script type="text/javascript">
            $("#backup").addClass("active");

            $(document).ready(function(){

                $('#backupdatabase-table').DataTable( {
                    "paging"        : true,
                    "ordering"      : false,
                    "info"          : false,
                    stateSave       : true,
                    "pagingType"    : "full_numbers",
                    "order"         : [[ 1, "desc" ]],
                    "iDisplayLength": 25
                } );

            });

            function createBackup()
            {
                pageLoadingFrame("show");

                $.post("backup/createBackup", {

                    user_id : <?php echo $_SESSION['user_id'] ?>

                }, function(data){

                    // pageLoadingFrame("hide");
                    window.location.reload();

                });
            }
        </script>       
    </body>
</html>






