<?php 
    session_start();

    if (isset($_SESSION['user_id'])) 
    {
        header("Location:transactions");
    }
?>
<!DOCTYPE html>
<html lang="en" class="body-full-height">
    <head>        
        <?php include 'shared/head.php'; ?>                                          
    </head>
    <body>
        <!-- <a href="assets/img/CodeBlooded.png" target="_blank">
            <img src="assets/img/CodeBlooded.png" style="width:150px; position:fixed; bottom:20px; right:20px;">
        </a> -->
        
        <div class="login-container">
        
            <div class="login-box animated fadeInDown">
                <div class="login-body" style="box-shadow:0 0 100px #25ACDA">
                    <!-- <div class="login-title"><strong><center style="color:#25ACDA;">THEOS WATER REFILLING SYSTEM</strong></center></div> -->
                    <img src="assets/theosLOGO.png" style="width:100%">
                    <form action="" class="form-horizontal" method="post">
                        <div class="form-group">
                            <div class="col-md-12">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="text" class="form-control" placeholder="Username" validation="signinform" id="username" required/>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-12">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                    <input type="password" class="form-control" placeholder="Password" validation="signinform" id="password" required/>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6">
                                <button class="btn btn-info btn-block" type="button" onclick="checkSignIn();">Log In</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="login-footer">
                    <div class="pull-left">
                        &copy; 2018 Theos Water Refilling System
                    </div>
                    <div class="pull-right">
                        
                    </div>
                </div>
            </div>
            
        </div>
        
    </body>
</html>

<?php include "shared/js.php"; ?>
<script type="text/javascript">

    $('#username, #password').keyup(function(e){ 
        if (e.keyCode == 13) 
        {
            checkSignIn();
        }
    });

    function checkSignIn()
    {
        if (!codeblooded.validateForm('signinform')) 
        {
            return;
        }

        $.post("admin/checkSignIn", {

            username : $("#username").val(),
            password : $("#password").val(),

        }, function(data){

            var result = eval("("+data+")");

            if (result.error == true) 
            {
                noty({
                    text: result.message,
                    layout: "topRight",
                    type : "error"
                })
            }
            else
            {
                window.location.href = "transactions";
            }

        });

    }
</script>
