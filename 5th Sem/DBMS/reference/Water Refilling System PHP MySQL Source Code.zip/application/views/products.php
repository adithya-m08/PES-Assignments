<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <div class="page-title">                    
                    <h2><span class="fa fa-th"></span> Products</h2>
                </div>                   
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">                
                    
                    <div class="content-frame">
                        
                        <!-- START CONTENT FRAME TOP -->
                        <div class="content-frame-top">                        
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-7">
                                        <table class="table-condensed table-striped datatable" width="100%">
                                            <thead>
                                                <tr style="background:#fff">
                                                    <td><b>Name</b></td>
                                                    <td><b>Description</b></td>
                                                    <td><b>Price</b></td>
                                                    <td><b>Stocks</b></td>
                                                    <td width="100px"><b>Action</b></td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php $query = $codeblooded->crud->getData("tbl_products", "is_deleted = 0"); ?>
                                            <?php foreach ($query['rows'] as $key): ?>

                                                <?php 
                                                    $stocksSql = $codeblooded->crud->getData("tbl_product_inventory", "p_id = $key->p_id");


                                                    $stocksSql2 = $codeblooded->crud->getData("tbl_transaction_items", "p_id = $key->p_id");
                                                    $stocksSql3 = $codeblooded->crud->getData("tbl_product_inventory", "p_id = $key->p_id AND pi_condition = 'Damaged'")['total'];

                                                    $stocks = $stocksSql['total'] - $stocksSql3;

                                                    foreach ($stocksSql2['rows'] as $sk2) 
                                                    {
                                                        $stocks -= $sk2->qty;
                                                    }

                                                    if ($stocks < 0) 
                                                    {
                                                        $stocks = "";
                                                    }
                                                ?>

                                                <tr id="tr-<?php echo $key->p_id ?>" style="background:#fff" ondblclick="showEdit(<?php echo $key->p_id ?>)">
                                                    <td>
                                                        <span class="p_name-<?php echo $key->p_id ?>"><?php echo $key->p_name ?></span>
                                                        <input type="text" value="<?php echo $key->p_name ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->p_id ?>" id="p_name-<?php echo $key->p_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="p_description-<?php echo $key->p_id ?>"><?php echo $key->p_description ?></span>
                                                        <input type="text" value="<?php echo $key->p_description ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->p_id ?>" id="p_description-<?php echo $key->p_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="p_price-<?php echo $key->p_id ?>"><?php echo $key->p_price ?></span>
                                                        <input type="text" value="<?php echo $key->p_price ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->p_id ?>" id="p_price-<?php echo $key->p_id ?>">
                                                    </td>
                                                    <td>
                                                        <a href="#" data-toggle="modal" data-target="#stock-modal-<?php echo $key->p_id ?>">
                                                            <b style="font-weight:900"><?php echo $stocks; ?></b>
                                                        </a>


                                                        <div class="modal" id="stock-modal-<?php echo $key->p_id ?>" tabindex="-1" role="dialog" aria-labelledby="smallModalHead" aria-hidden="true">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                                                        <h4 class="modal-title" id="smallModalHead"><?php echo $key->p_name ?></h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <table class="table table-condensed datatable">
                                                                            <thead>
                                                                                <tr>
                                                                                    <th>Item Code</th>
                                                                                    <th></th>
                                                                                </tr>
                                                                            </thead>
                                                                            <tbody>
                                                                            <?php foreach ($stocksSql['rows'] as $skey): ?>
                                                                                <tr>
                                                                                    <td><?php echo $skey->pi_item_code ?></td>
                                                                                    <td align="right">
                                                                                        <button class="btn btn-sm <?php echo (($skey->pi_condition == "Good")? "btn-success" : "btn-danger"); ?>" 
                                                                                            onclick="changeCondition(<?php echo $skey->pi_id ?>, '<?php echo (($skey->pi_condition == "Good")? "Damaged" : "Good"); ?>')">
                                                                                            <?php echo $skey->pi_condition ?>
                                                                                        </button>
                                                                                    </td>
                                                                                </tr>
                                                                            <?php endforeach ?>
                                                                            </tbody>
                                                                        </table>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>                        
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>   
                                                    </td>
                                                    <td align="right">
                                                        <ul class="panel-controls">
                                                            <li onclick="addStock(<?php echo $key->p_id ?>)">
                                                                <a href="#"><span class="fa fa-plus"></span></a>
                                                            </li>
                                                            <li style="display:none" class="edit-<?php echo $key->p_id ?>" 
                                                                onclick="updateData(<?php echo $key->p_id ?>)">
                                                                <a href="#"><span class="fa fa-save"></span></a>
                                                            </li>
                                                            <li class="remove-<?php echo $key->p_id ?>" 
                                                                onclick="deleteData(<?php echo $key->p_id ?>)">
                                                                <a href="#"><span class="fa fa-times"></span></a>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                            <?php endforeach ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="3">
                                                        <i><b>Note : </b>Double click item to edit.</i>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <div class="col-md-5">
                                        <form method="POST" class="form-horizontal" id="add-form">
                                            <input type="hidden" name="table" value="tbl_products">
                                            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id'] ?>">
                                            <div class="panel panel-default" style="background-color:#eee;">
                                                <div class="panel-body">
                                                    <h3 class="panel-title">Add Product</h3>
                                                </div>
                                                <div class="panel-body form-group-separated">
                                                    <div class="form-group">
                                                        <label class="col-md-3 col-xs-5 control-label">Product Name</label>
                                                        <div class="col-md-9 col-xs-7">
                                                            <input type="text" class="form-control" validation="add-form" name="p_name">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-3 col-xs-5 control-label">Description</label>
                                                        <div class="col-md-9 col-xs-7">
                                                            <input type="text" class="form-control" name="p_description">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-3 col-xs-5 control-label">Price</label>
                                                        <div class="col-md-9 col-xs-7">
                                                            <input type="text" class="form-control" validation="add-form" name="p_price">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel-footer" style="background-color:#eee;">
                                                    <div class="col-md-12 col-xs-12">
                                                        <button type="button" class="btn btn-primary pull-right" onclick="addData()">Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>                      
                        </div>
                        <!-- END CONTENT FRAME TOP -->
                        
                    </div>
                
                </div>
                <!-- PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->


        <?php include "shared/js.php"; ?>
        <script type="text/javascript">
            // $("#filemaintenance, #courses").addClass("active");

            function addData()
            {
                if (!codeblooded.validateForm("add-form")) 
                {
                    return;
                }

                $.post("codeblooded/addDataManual", 

                    $("#add-form").serialize()

                ,function(data){

                    window.location.reload();

                });
            }

            function showEdit(p_id)
            {
                $(".p_name-"+p_id+", .p_description-"+p_id+", .p_price-"+p_id+", .remove-"+p_id).css({ "display" : "none" });
                $(".edit-"+p_id).css({ "display" : "block" });
            }

            function updateData(p_id)
            {
                $.post("codeblooded/editDataManual", {

                    table : "tbl_products",
                    user_id : <?php echo $_SESSION['user_id'] ?>,
                    key : "p_id",
                    keyval : p_id,
                    p_name : $("#p_name-"+p_id).val(),
                    p_description : $("#p_description-"+p_id).val(),
                    p_price : $("#p_price-"+p_id).val()

                }, function(data){

                    $(".p_name-"+p_id).html($("#p_name-"+p_id).val());
                    $(".p_description-"+p_id).html($("#p_description-"+p_id).val());
                    $(".p_price-"+p_id).html($("#p_price-"+p_id).val());

                    $(".p_name-"+p_id+", .p_description-"+p_id+", .p_price-"+p_id+", .remove-"+p_id).css({ "display" : "block" });
                    $(".edit-"+p_id).css({ "display" : "none" });

                });
            }

            function deleteData(p_id)
            {
                noty({
                    text: 'Are you sure you want to delete this data?',
                    layout: 'topCenter',
                    buttons: [
                        {
                            addClass: 'btn btn-success btn-clean', text: 'Ok', onClick: function($noty) 
                            {
                                $noty.close();
                                    
                                $.post("codeblooded/deleteDataManual", {

                                    table : "tbl_products",
                                    key : "p_id",
                                    user_id : <?php echo $_SESSION['user_id'] ?>,
                                    keyval : p_id,
                                    is_deleted : 1

                                }, function(data){

                                    $("#tr-"+p_id).remove();

                                });
                            }
                        },
                        {
                            addClass: 'btn btn-danger btn-clean', text: 'Cancel', onClick: function($noty) 
                            {
                                $noty.close();
                            }
                        }
                    ]
                }) 

            }

            function addStock(p_id)
            {
                var val = prompt("Add Stocks:");

                if (val === null || val === "" || isNaN(val))
                {
                    return;
                }

                $.post("products/addStock", {

                    val : val,
                    p_id : p_id

                }, function(data){

                    // alert(data);

                    window.location.reload();

                });
            }

            function changeCondition(pi_id, pi_condition)
            {
                $.post("codeblooded/editDataManual", {

                    table : "tbl_product_inventory",
                    user_id : <?php echo $_SESSION['user_id']; ?>,
                    key : "pi_id",
                    keyval : pi_id,
                    pi_condition : pi_condition

                }, function(data){

                    window.location.reload();

                });
            }
        </script>
    </body>
</html>






