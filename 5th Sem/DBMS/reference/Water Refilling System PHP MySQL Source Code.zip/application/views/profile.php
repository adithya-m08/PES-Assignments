<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <div class="page-title">                    
                    <h2><span class="fa fa-user"></span> Profile</h2>
                </div>                   
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">                
                    
                    <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-4">
                                        <form method="POST" class="form-horizontal" id="edit-form">
                                            <input type="hidden" name="table" value="tbl_users">
                                            <input type="hidden" name="key" value="user_id">
                                            <input type="hidden" name="keyval" value="<?php echo $_SESSION['user_id'] ?>">
                                            <div class="panel panel-default" style="background-color:#eee;">
                                                <div class="panel-body">
                                                    <h3 class="panel-title">Personal Information</h3>
                                                </div>
                                                <div class="panel-body form-group-separated">
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Name</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="name" value="<?php echo $userData->name ?>">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">E-Mail</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="email" value="<?php echo $userData->email ?>">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Contact No.</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="contact" value="<?php echo $userData->contact ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel-footer" style="background-color:#eee;">
                                                    <div class="col-md-12 col-xs-12">
                                                        <button type="button" class="btn btn-primary pull-right" onclick="editData()">
                                                            <i class="fa fa-save"></i> Update
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-md-4">
                                        <form method="POST" class="form-horizontal">
                                            <div class="panel panel-default" style="background-color:#eee;">
                                                <div class="panel-body">
                                                    <h3 class="panel-title">Account Information</h3>
                                                </div>
                                                <div class="panel-body form-group-separated">
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Username</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" validation="user-account" value="<?php echo $userData->username ?>" id="username">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Password</label>
                                                        <div class="col-md-7">
                                                            <input type="password" class="form-control" validation="user-account" id="password">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Verify Password</label>
                                                        <div class="col-md-7">
                                                            <input type="password" class="form-control" validation="user-account" id="password2">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel-footer" style="background-color:#eee;">
                                                    <div class="col-md-12 col-xs-12">
                                                        <button type="button" class="btn btn-primary pull-right" onclick="updateAccount()">
                                                            <i class="fa fa-save"></i> Update
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                    </div>
                
                </div>
                <!-- PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <?php include "shared/js.php"; ?>
        <script type="text/javascript">
            $("#profile").addClass("active");

            function editData()
            {
                $.post("codeblooded/editData", 

                    $("#edit-form").serialize()

                ,function(data){

                    noty({
                        text: "Updated successfully. [Click to dismiss]",
                        layout: "topRight",
                        type : "success"
                    })

                });
            }

            function updateAccount()
            {
                if (!codeblooded.validateForm("user-account")) 
                {
                    return;
                }

                if ($("#password").val() != $("#password2").val()) 
                {
                    noty({
                        text: "Passwords don't match. [Click to dismiss]",
                        layout: "topRight",
                        type : "error"
                    })

                    return;
                }

                $.post("profile/updateAccount", {

                    user_id : <?php echo $_SESSION['user_id'] ?>,
                    username : $("#username").val(),
                    password : $("#password").val()

                }, function(data){

                    noty({
                        text: "Updated successfully. [Click to dismiss]",
                        layout: "topRight",
                        type : "success"
                    })

                });
            }
        </script>       
    </body>
</html>






