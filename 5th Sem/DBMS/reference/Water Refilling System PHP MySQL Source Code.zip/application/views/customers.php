<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <div class="page-title">                    
                    <h2><span class="fa fa-users"></span> Customers</h2>
                </div>                   
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">                
                    
                    <div class="content-frame">
                        
                        <!-- START CONTENT FRAME TOP -->
                        <div class="content-frame-top">                        
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-7">
                                        <table class="table-condensed table-striped datatable" width="100%">
                                            <thead>
                                                <tr style="background:#fff">
                                                    <td><b>First Name</b></td>
                                                    <td><b>Family Name</b></td>
                                                    <td><b>Address</b></td>
                                                    <td><b>Contact Number</b></td>
                                                    <td width="100px"><b>Action</b></td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php $query = $codeblooded->crud->getData("tbl_customers", "is_deleted = 0"); ?>
                                            <?php foreach ($query['rows'] as $key): ?>
                                                <tr id="tr-<?php echo $key->c_id ?>" style="background:#fff" ondblclick="showEdit(<?php echo $key->c_id ?>)">
                                                    <td>
                                                        <span class="c_name-<?php echo $key->c_id ?>"><?php echo $key->c_name ?></span>
                                                        <input type="text" value="<?php echo $key->c_name ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->c_id ?>" id="c_name-<?php echo $key->c_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="c_lastname-<?php echo $key->c_id ?>"><?php echo $key->c_lastname ?></span>
                                                        <input type="text" value="<?php echo $key->c_lastname ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->c_id ?>" id="c_lastname-<?php echo $key->c_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="c_address-<?php echo $key->c_id ?>"><?php echo $key->c_address ?></span>
                                                        <input type="text" value="<?php echo $key->c_address ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->c_id ?>" id="c_address-<?php echo $key->c_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="c_contact-<?php echo $key->c_id ?>"><?php echo $key->c_contact ?></span>
                                                        <input type="text" value="<?php echo $key->c_contact ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->c_id ?>" id="c_contact-<?php echo $key->c_id ?>">
                                                    </td>
                                                    <td align="right">
                                                        <ul class="panel-controls">
                                                            <li onclick="viewLedger(<?php echo $key->c_id ?>)" data-toggle="tooltip" title="View Ledger">
                                                                <a href="#"><span class="fa fa-list-alt"></span></a>
                                                            </li>
                                                            <li style="display:none" class="edit-<?php echo $key->c_id ?>" 
                                                                onclick="updateData(<?php echo $key->c_id ?>)">
                                                                <a href="#"><span class="fa fa-save"></span></a>
                                                            </li>
                                                            <li class="remove-<?php echo $key->c_id ?>" 
                                                                onclick="deleteData(<?php echo $key->c_id ?>)">
                                                                <a href="#"><span class="fa fa-times"></span></a>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                            <?php endforeach ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="3">
                                                        <i><b>Note : </b>Double click item to edit.</i>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <div class="col-md-5">
                                        <form method="POST" class="form-horizontal" id="add-form">
                                            <input type="hidden" name="table" value="tbl_customers">
                                            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id'] ?>">
                                            <div class="panel panel-default" style="background-color:#eee;">
                                                <div class="panel-body">
                                                    <h3 class="panel-title">Add Customer</h3>
                                                </div>
                                                <div class="panel-body form-group-separated">
                                                    <div class="form-group">
                                                        <label class="col-md-3 col-xs-5 control-label">Name</label>
                                                        <div class="col-md-9 col-xs-7">
                                                            <input type="text" class="form-control" validation="add-form" name="c_name">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-3 col-xs-5 control-label">Family Name</label>
                                                        <div class="col-md-9 col-xs-7">
                                                            <input type="text" class="form-control" validation="add-form" name="c_lastname">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-3 col-xs-5 control-label">Address</label>
                                                        <div class="col-md-9 col-xs-7">
                                                            <input type="text" class="form-control" validation="add-form" name="c_address">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-3 col-xs-5 control-label">Contact Number</label>
                                                        <div class="col-md-9 col-xs-7">
                                                            <input type="text" class="form-control" validation="add-form" name="c_contact">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel-footer" style="background-color:#eee;">
                                                    <div class="col-md-12 col-xs-12">
                                                        <button type="button" class="btn btn-primary pull-right" onclick="addData()">Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>                      
                        </div>
                        <!-- END CONTENT FRAME TOP -->
                        
                    </div>
                
                </div>
                <!-- PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->


        <?php include "shared/js.php"; ?>
        <script type="text/javascript">
            // $("#filemaintenance, #courses").addClass("active");

            function viewLedger(c_id)
            {
                <?php $url = explode("/", $_SERVER['REQUEST_URI']); ?>

                window.open("../<?php echo "../".$url[1]."/printcustomerledger?id="; ?>" + c_id, "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=10, left=50, width=800, height=" + window.screen.height/3*2.5);
            }

            function addData()
            {
                if (!codeblooded.validateForm("add-form")) 
                {
                    return;
                }

                $.post("codeblooded/addDataManual", 

                    $("#add-form").serialize()

                ,function(data){

                    window.location.reload();

                });
            }

            function showEdit(c_id)
            {
                $(".c_name-"+c_id+", .c_lastname-"+c_id+", .c_address-"+c_id+", .c_contact-"+c_id+", .remove-"+c_id).css({ "display" : "none" });
                $(".edit-"+c_id).css({ "display" : "block" });
            }

            function updateData(c_id)
            {
                $.post("codeblooded/editDataManual", {

                    table : "tbl_customers",
                    user_id : <?php echo $_SESSION['user_id'] ?>,
                    key : "c_id",
                    keyval : c_id,
                    c_name : $("#c_name-"+c_id).val(),
                    c_lastname : $("#c_lastname-"+c_id).val(),
                    c_address : $("#c_address-"+c_id).val(),
                    c_contact : $("#c_contact-"+c_id).val()

                }, function(data){

                    $(".c_name-"+c_id).html($("#c_name-"+c_id).val());
                    $(".c_lastname-"+c_id).html($("#c_lastname-"+c_id).val());
                    $(".c_address-"+c_id).html($("#c_address-"+c_id).val());
                    $(".c_contact-"+c_id).html($("#c_contact-"+c_id).val());

                    $(".c_name-"+c_id+", .c_lastname-"+c_id+", .c_address-"+c_id+", .c_contact-"+c_id+", .remove-"+c_id).css({ "display" : "block" });
                    $(".edit-"+c_id).css({ "display" : "none" });

                });
            }

            function deleteData(c_id)
            {
                noty({
                    text: 'Are you sure you want to delete this data?',
                    layout: 'topCenter',
                    buttons: [
                        {
                            addClass: 'btn btn-success btn-clean', text: 'Ok', onClick: function($noty) 
                            {
                                $noty.close();
                                    
                                $.post("codeblooded/editDataManual", {

                                    table : "tbl_customers",
                                    user_id : <?php echo $_SESSION['user_id'] ?>,
                                    key : "c_id",
                                    keyval : c_id,
                                    is_deleted : 1

                                }, function(data){

                                    $("#tr-"+c_id).remove();

                                });
                            }
                        },
                        {
                            addClass: 'btn btn-danger btn-clean', text: 'Cancel', onClick: function($noty) 
                            {
                                $noty.close();
                            }
                        }
                    ]
                }) 

            }
        </script>
    </body>
</html>






