<?php 
    session_start();

    date_default_timezone_set("Asia/Manila");

    $codeblooded =& get_instance();
    $codeblooded->load->model("crud");

    if (isset($_SESSION['user_id']))
    {
        $userData = $codeblooded->crud->getData("tbl_users", "user_id = $_SESSION[user_id]");
        $userData = $userData['rows'][0];
    }
    else
    {
        echo "<script>";
        echo "window.location.href='admin';";
        echo "</script>";
    }

    $url = explode("/", $_SERVER['REQUEST_URI']);
?>
