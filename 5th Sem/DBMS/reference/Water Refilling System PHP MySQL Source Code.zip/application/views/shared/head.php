<!-- META SECTION -->
<title>Theos Water Refilling System</title>            
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
        
<link rel="icon" href="assets/img/CBicon.png" type="image/x-icon" />
<!-- END META SECTION -->
        
<!-- CSS INCLUDE -->        
<link rel="stylesheet" type="text/css" id="theme" href="assets/css/theme-default.css"/>
<!-- EOF CSS INCLUDE --> 

<!--.................................................................................................................................................
//....CCCCCCC......OOOOOOO.....DDDDDDDDD....EEEEEEEEEEE.BBBBBBBBBB...LLLL.........OOOOOOO.......OOOOOOO.....DDDDDDDDD....EEEEEEEEEEE.DDDDDDDDD.....
//...CCCCCCCCC....OOOOOOOOOO...DDDDDDDDDD...EEEEEEEEEEE.BBBBBBBBBBB..LLLL........OOOOOOOOOO....OOOOOOOOOO...DDDDDDDDDD...EEEEEEEEEEE.DDDDDDDDDD....
//..CCCCCCCCCCC..OOOOOOOOOOOO..DDDDDDDDDDD..EEEEEEEEEEE.BBBBBBBBBBB..LLLL.......OOOOOOOOOOOO..OOOOOOOOOOOO..DDDDDDDDDDD..EEEEEEEEEEE.DDDDDDDDDDD...
//..CCCC...CCCCC.OOOOO..OOOOO..DDDD...DDDD..EEEE........BBBB...BBBB..LLLL.......OOOOO..OOOOO..OOOOO..OOOOO..DDDD...DDDD..EEEE........DDDD...DDDD...
//.CCCC.....CCC.OOOOO....OOOOO.DDDD....DDDD.EEEE........BBBB...BBBB..LLLL......OOOOO....OOOOOOOOOO....OOOOO.DDDD....DDDD.EEEE........DDDD....DDDD..
//.CCCC.........OOOO......OOOO.DDDD....DDDD.EEEEEEEEEE..BBBBBBBBBBB..LLLL......OOOO......OOOOOOOO......OOOO.DDDD....DDDD.EEEEEEEEEE..DDDD....DDDD..
//.CCCC.........OOOO......OOOO.DDDD....DDDD.EEEEEEEEEE..BBBBBBBBBB...LLLL......OOOO......OOOOOOOO......OOOO.DDDD....DDDD.EEEEEEEEEE..DDDD....DDDD..
//.CCCC.........OOOO......OOOO.DDDD....DDDD.EEEEEEEEEE..BBBBBBBBBBB..LLLL......OOOO......OOOOOOOO......OOOO.DDDD....DDDD.EEEEEEEEEE..DDDD....DDDD..
//.CCCC.....CCC.OOOOO....OOOOO.DDDD....DDDD.EEEE........BBBB....BBBB.LLLL......OOOOO....OOOOOOOOOO....OOOOO.DDDD....DDDD.EEEE........DDDD....DDDD..
//..CCCC...CCCCC.OOOOO..OOOOO..DDDD...DDDDD.EEEE........BBBB....BBBB.LLLL.......OOOOO..OOOOO..OOOOO..OOOOO..DDDD...DDDDD.EEEE........DDDD...DDDDD..
//..CCCCCCCCCCC..OOOOOOOOOOOO..DDDDDDDDDDD..EEEEEEEEEEE.BBBBBBBBBBBB.LLLLLLLLLL.OOOOOOOOOOOO..OOOOOOOOOOOO..DDDDDDDDDDD..EEEEEEEEEEE.DDDDDDDDDDD...
//...CCCCCCCCCC...OOOOOOOOOO...DDDDDDDDDD...EEEEEEEEEEE.BBBBBBBBBBB..LLLLLLLLLL..OOOOOOOOOO....OOOOOOOOOO...DDDDDDDDDD...EEEEEEEEEEE.DDDDDDDDDD....
//....CCCCCCC.......OOOOOO.....DDDDDDDDD....EEEEEEEEEEE.BBBBBBBBBB...LLLLLLLLLL....OOOOOO........OOOOOO.....DDDDDDDDD....EEEEEEEEEEE.DDDDDDDDD.....
//.................................................................................................................................................-->

<!-- <a href="assets/img/CodeBlooded.png" target="_blank">
	<img src="assets/img/CodeBlooded.png" style="width:150px; position:fixed; bottom:20px; left:20px; z-index:1000;">
</a>