                <ul class="x-navigation x-navigation-horizontal">
                    <!-- <li id="profile"><a href="profile"><span class="fa fa-user"></span><span class="xn-text">Profile</span></a></li> -->
                    <li id="transactions"><a href="transactions"><span class="fa fa-shopping-cart"></span><span class="xn-text">Transactions</span></a></li>
                    <li id="deliveries"><a href="deliveries"><span class="fa fa-truck"></span><span class="xn-text">Deliveries</span></a></li>
                    <li id="expenses"><a href="expenses"><span class="fa fa-usd"></span><span class="xn-text">Expenses</span></a></li>
                    <li class="xn-openable" id="filemaintenance">
                        <a href="#"><span class="fa fa-wrench"></span> <span class="xn-text">File Maintenance</span></a>
                        <ul class="animated zoomIn">
                            <li id="products"><a href="products"><span class="fa fa-circle"></span> Products</a></li>
                            <li id="customers"><a href="customers"><span class="fa fa-circle"></span> Customers</a></li>
                        </ul>
                    </li>
                    <li id="reports"><a href="reports"><span class="fa fa-folder-open"></span><span class="xn-text">Sales/Expenses Report</span></a></li>
                    <li id="backup"><a href="backup"><span class="fa fa-download"></span><span class="xn-text">Backup Database</span></a></li>
                    <!-- POWER OFF -->
                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-power-off"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="admin/signout" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span> Sign Out</a></li>
                        </ul>                        
                    </li> 
                    <!-- END POWER OFF -->
                    <!-- END SEARCH -->                     
                </ul>