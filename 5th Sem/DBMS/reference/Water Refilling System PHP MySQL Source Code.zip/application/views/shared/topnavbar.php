                <div class="page-content-header">
                    <a href="dashboard" class="logo"></a>
                    <div class="pull-right">                        
                        <div class="socials">
                            <a href="#"><span class="fa fa-facebook-square"></span></a>
                            <a href="#"><span class="fa fa-twitter-square"></span></a>                                                
                        </div>
                        <div class="contacts">
                            <a href="#"><span class="fa fa-envelope"></span> <?php echo $userData->email ?></a>
                            <a href="#"><span class="fa fa-phone"></span> <?php echo $userData->contact ?></a>
                        </div>
                    </div>
                </div>