<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb push-down-0">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <div class="content-frame">
                    
                    <!-- START CONTENT FRAME TOP -->
                    <div class="content-frame-top">                        
                        <div class="page-title">                    
                            <h2><span class="fa fa-usd"></span> Expenses</h2>
                        </div>                                      
                        <div class="pull-right">
                            <button class="btn btn-default content-frame-left-toggle"><span class="fa fa-bars"></span></button>
                        </div>                        
                    </div>
                    <!-- END CONTENT FRAME TOP -->
                    
                    <!-- START CONTENT FRAME LEFT -->
                    <div class="content-frame-left">
                        <form method="POST" id="expenses-form" enctype="multipart/form-data" action="expenses/addExpenses">
                            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id'] ?>">
                            <table class="table-condensed table-bordered" width="100%">
                                <tr>
                                    <td>
                                        <label>Date</label>
                                        <input type="date" class="form-control" name="e_date" validation="expenses-form">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label>Remarks</label>
                                        <textarea class="form-control" name="e_description" validation="expenses-form" style="resize:none" rows="3"></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label>Amount</label>
                                        <input type="text" class="form-control" name="e_amount" onkeypress="validate(event)" validation="expenses-form">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label>Receipt</label>
                                        <input type="file" class="form-control" name="e_receipt" validation="expenses-form">
                                    </td>
                                </tr>
                                <tr>
                                    <td align="right">
                                        <button class="btn btn-primary" type="button" onclick="addExpenses()">
                                            Submit
                                        </button>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                    <!-- END CONTENT FRAME LEFT -->
                    
                    <!-- START CONTENT FRAME BODY -->
                    <div class="content-frame-body">
                        
                        <div class="panel panel-default" style="border-radius:0">
                            <div class="panel-body">
                                <table class="table-condensed table-striped datatable" width="100%">
                                    <thead>
                                        <tr>
                                            <th style="text-align:center !important" width="15%">Date/Time</th>
                                            <th style="text-align:center !important" width="15%">Remarks</th>
                                            <th style="text-align:center !important" width="15%">Amount</th>
                                            <th style="text-align:center !important" width="15%">Receipt</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $expensesQuery = $codeblooded->crud->getData("tbl_expenses", "1 ORDER BY e_date")['rows']; ?>
                                    <?php foreach ($expensesQuery as $key): ?>
                                        <tr>
                                            <td align="center"><?php echo date("m/d/Y, h:iA", strtotime($key->e_date)) ?></td>
                                            <td align="center"><?php echo $key->e_description ?></td>
                                            <td align="center"><?php echo number_format($key->e_amount, 2) ?></td>
                                            <td align="center">
                                                <a href="assets/images/receipts/<?php echo $key->e_receipt ?>" target="_blank">
                                                    <!-- <img class="img-thumbnail" src="assets/images/receipts/<?php //echo $key->e_receipt ?>"> -->
                                                    <?php echo $key->e_receipt ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- END CONTENT FRAME BODY -->
                </div>

            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <?php include "shared/js.php"; ?>
        <script type="text/javascript">
            $("#expenses").addClass("active");

            function addExpenses()
            {
                if (!codeblooded.validateForm('expenses-form')) 
                {
                    return;
                }

                $("#expenses-form").submit();
            }

            function validate(evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                key = String.fromCharCode( key );
                var regex = /[0-9]|\./;
                if( !regex.test(key) ) {
                    theEvent.returnValue = false;
                    if(theEvent.preventDefault) theEvent.preventDefault();
                }
            }
        </script>       
    </body>
</html>






