<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb push-down-0">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <div class="content-frame">
                    
                    <!-- START CONTENT FRAME TOP -->
                    <div class="content-frame-top">                        
                        <div class="page-title">                    
                            <h2><span class="fa fa-shopping-cart"></span> Transactions (<?php echo date('m/d/Y') ?>)</h2>
                        </div>                                      
                        <div class="pull-right">
                            <button class="btn btn-default content-frame-left-toggle"><span class="fa fa-bars"></span></button>
                            <button class="btn btn-default" data-toggle="modal" data-target="#add-transaction-modal">
                                Add Transaction
                            </button>
                        </div>                        
                    </div>
                    <!-- END CONTENT FRAME TOP -->
                    
                    <!-- START CONTENT FRAME LEFT -->
                    <!-- <div class="content-frame-left">
                        
                    </div> -->
                    <!-- END CONTENT FRAME LEFT -->
                    
                    <!-- START CONTENT FRAME BODY -->
                    <div class="content-frame-body" style="margin-left:0">
                        
                        <div class="panel panel-default" style="border-radius:0">
                            <div class="panel-body">
                                <button style="margin-bottom:10px" class="btn btn-default pull-right" onclick="accountreceivable()">
                                    Account Receivable
                                </button>

                                <button style="margin-bottom:10px" class="btn btn-primary btn-rounded" id="show-all" 
                                onclick="$('.walkin, .delivery').show(); $(this).attr('disabled', 'disabled'); $('#show-walkin, #show-delivery').removeAttr('disabled');" disabled>
                                    Show All
                                </button>
                                <button style="margin-bottom:10px" class="btn btn-primary btn-rounded" id="show-walkin" 
                                onclick="$('.walkin').show(); $('.delivery').hide(); $(this).attr('disabled', 'disabled'); $('#show-all, #show-delivery').removeAttr('disabled');">
                                    Show Walk in
                                </button>
                                <button style="margin-bottom:10px" class="btn btn-primary btn-rounded" id="show-delivery" 
                                onclick="$('.walkin').hide(); $('.delivery').show(); $(this).attr('disabled', 'disabled'); $('#show-walkin, #show-all').removeAttr('disabled');">
                                    Show Delivery
                                </button>

                                <table class="table-condensed table-striped datatable" width="100%">
                                    <thead>
                                        <tr>
                                            <th style="text-align:center !important" width="10%">OR Number</th>
                                            <th style="text-align:center !important" width="15%">Date/Time</th>
                                            <th style="text-align:center !important" width="15%">Customer</th>
                                            <th style="text-align:center !important" width="25%">Orders</th>
                                            <th style="text-align:center !important" width="20%">Total amount</th>
                                            <th style="text-align:center !important" width="5%">Type</th>
                                            <th style="text-align:center !important" width="5%">Status</th>
                                            <th style="text-align:center !important" width="5%">Delivered</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $transactionsQuery = $codeblooded->crud->getData("tbl_transactions", "LEFT(t_date, 10) = '". date('Y-m-d') ."' OR is_paid = 0 ORDER BY t_date desc")['rows']; ?>
                                    <?php foreach ($transactionsQuery as $key): ?>

                                        <?php 
                                            $orders = array();
                                            $customer = strtoupper($key->t_customer);

                                            if (!is_null($key->c_id) && $key->c_id != 0) 
                                            {
                                                $customerQuery = $codeblooded->crud->getData("tbl_customers", "c_id = $key->c_id")['rows'];

                                                $customer = strtoupper($customerQuery[0]->c_name." ".$customerQuery[0]->c_lastname);
                                            }

                                            $items = $codeblooded->crud->getData(
                                                "tbl_transaction_items ti, tbl_products p", 
                                                "ti.p_id = p.p_id AND ti.t_id = $key->t_id"
                                            )['rows'];

                                            foreach ($items as $i) 
                                            {
                                                array_push($orders, "$i->p_name ($i->qty * $i->price ". /*number_format($i->price, 2) .*/"php)");
                                            }

                                            switch ($key->is_delivery) 
                                            {
                                                case 0: $type = "Walk in"; $class = "walkin"; break;
                                                case 1: $type = "Delivery"; $class = "delivery"; break;
                                            }

                                            switch ($key->is_paid) 
                                            {
                                                case 0: $status = "<button class='btn btn-sm btn-success' onclick=\"addPayment($key->t_id, '$key->t_total')\">Add payment</button>"; break;
                                                case 1: $status = "<b>Paid</b>"; break;
                                            }


                                            $delivered = "";

                                            if ($key->is_delivery == 1) 
                                            {
                                                switch ($key->is_delivered) 
                                                {
                                                    case 0: $delivered = "<i class='fa fa-times' style='cursor:pointer; color:red;' onclick='delivered($key->t_id, 1)'></i>"; break;
                                                    case 1: $delivered = "<i class='fa fa-check' style='cursor:pointer; color:green;' onclick='delivered($key->t_id, 0)'></i>"; break;
                                                }
                                            }
                                        ?>

                                        <tr class="<?php echo $class ?>">
                                            <td align="center">
                                                <?php if ($key->is_paid == 1): ?>
                                                <i class="fa fa-print fa-2x" style="cursor:pointer" onclick="printReceipt(<?php echo $key->t_id ?>)"></i>
                                                <?php endif ?>
                                                
                                                <?php echo $key->t_ornumber ?>
                                            </td>
                                            <td align="center"><?php echo date("m/d/Y - h:iA", strtotime($key->t_date)) ?></td>
                                            <td align="center"><?php echo $customer ?></td>
                                            <td align="center"><?php echo implode("<br>", $orders) ?></td>
                                            <td align="center"><?php echo number_format($key->t_total, 2) ?></td>
                                            <td align="center"><?php echo $type ?></td>
                                            <td align="center"><?php echo $status ?></td>
                                            <td align="center" id="delivered-<?php echo $key->t_id ?>"><?php echo $delivered ?></td>
                                        </tr>
                                    <?php endforeach ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- END CONTENT FRAME BODY -->
                </div>

            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <div class="modal" id="add-transaction-modal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title" id="defModalHead">Add Transaction</h4>
                    </div>
                    <div class="modal-body">
                        <form method="POST" id="transaction-form">
                            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id'] ?>">
                            <table class="table-condensed" width="100%">
                                <tr>
                                    <td colspan="2">
                                        <label id="t_ornumber_label">OR Number</label>
                                        <input type="text" class="form-control" name="t_ornumber" id="t_ornumber">
                                    </td>
                                    <td>
                                        <label>Type</label>
                                        <select class="form-control select" data-style="btn-success" name="is_delivery">
                                            <option value="0">Walk in</option>
                                            <option value="1">Delivery</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3">
                                        <label>Customer</label>
                                        <select class="form-control select" data-live-search="true" name="c_id">
                                            <option selected>-- Select customer --</option>
                                            <?php $query = $codeblooded->crud->getData("tbl_customers", "is_deleted = 0")['rows']; ?>
                                            <?php foreach ($query as $key): ?>
                                            <option value="<?php echo $key->c_id ?>"><?php echo "$key->c_name $key->c_lastname" ?></option>
                                            <?php endforeach ?>
                                        </select>
                                        <hr>
                                        <p style="margin-top:10px"><i><b>If not registered in the system.</b></i></p>
                                        <input type="text" class="form-control" placeholder="Name" name="t_customer" style="margin-top:5px; text-transform:uppercase;">
                                        <input type="text" class="form-control" placeholder="Address" name="t_address" style="margin-top:5px">
                                        <input type="text" class="form-control" placeholder="Contact No." name="t_contact" style="margin-top:5px">
                                        <hr>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">Item</td>
                                    <td>Qty</td>
                                </tr>
                                <?php $query = $codeblooded->crud->getData("tbl_products", "is_deleted = 0")['rows']; ?>
                                <?php foreach ($query as $key): ?>
                                <tr style="background:#fff">
                                    <td width="20px" align="center">
                                        <input type="checkbox" id="checkbox-<?php echo $key->p_id ?>"
                                        name="p_id[<?php echo $key->p_id ?>]" value="<?php echo $key->p_id ?>" 
                                        onclick="toggleDisable(<?php echo $key->p_id ?>)">
                                    </td>    
                                    <td><label for="checkbox-<?php echo $key->p_id ?>"><?php echo $key->p_name ?></label></td> 
                                    <td width="50px">
                                        <input type="text" class="form-control text-center" id="qty-<?php echo $key->p_id ?>" onkeyup="getTotalAmount(<?php echo $key->p_id ?>)" onkeypress="validate(event)" name="qty[<?php echo $key->p_id ?>]" style="padding:4px 0" disabled>
                                    </td> 
                                </tr>
                                <?php endforeach ?>
                                <tr>
                                    <td colspan="3">
                                        <label>Total</label>
                                        <input type="text" class="form-control" value="0.00" name="t_total" id="t_total" readonly style="color:#111; background:#fff; cursor:not-allowed;">
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3">
                                        <table width="100%">
                                            <tr>
                                                <td>
                                                    <label>Amount Gave</label>
                                                    <input type="text" class="form-control" value="0.00" onkeypress="validate(event)" name="t_amountgave" id="t_amountgave" onkeyup="getChange()">
                                                </td>
                                                <td>
                                                    <label>Change</label>
                                                    <input type="text" class="form-control" value="0.00" id="t_change" name="t_change" readonly style="color:#111; background:#fff; cursor:not-allowed;">
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3" align="right">
                                        <button class="btn btn-primary" type="button" onclick="addTransaction()">
                                            Submit
                                        </button>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <?php include "shared/js.php"; ?>
        <script type="text/javascript">
            $("#transactions").addClass("active");

            function enableOR(val)
            {
                if (val == 1) 
                {
                    // $("#t_ornumber").removeAttr("disabled");
                    $("#t_ornumber, #t_ornumber_label").css({ "display" : "block" });
                }
                else
                {
                    // $("#t_ornumber").attr("disabled", "disabled");
                    $("#t_ornumber, #t_ornumber_label").css({ "display" : "none" });
                }
            }

            function getTotalAmount()
            {
                $.post("transactions/getTotalAmount", 

                    $("#transaction-form").serialize()

                , function(data){

                    var result = eval('('+data+')');

                    $("#t_total").val( result.total);

                });
            }

            function getChange()
            {
                var change = 0;

                if (parseFloat($("#t_amountgave").val()) > parseFloat($("#t_total").val())) 
                {
                    change = parseFloat($("#t_amountgave").val()) - parseFloat($("#t_total").val());
                }

                $("#t_change").val(change);
            }

            function addTransaction()
            {
                $.post("transactions/addTransaction", 

                    $("#transaction-form").serialize()

                , function(data){

                    // alert(data);

                    var result = eval("("+data+')');

                    if (result.error == true) 
                    {
                        noty({
                            text: result.message+". [Click to dismiss]",
                            layout: "topRight",
                            type : "error"
                        })
                    }
                    else
                    {
                        window.location.reload();
                    }

                });
            }

            function toggleDisable(p_id)
            {
                checkbox = $("#checkbox-"+p_id);
                qty = $("#qty-"+p_id);

                if (checkbox.prop("checked") == true) 
                {
                    qty.removeAttr("disabled").val(1);
                }
                else
                {
                    qty.attr("disabled", "disabled").val(0);
                }

                getTotalAmount(p_id);
            }

            function addPayment(t_id, t_total)
            {
                amount = prompt("Enter amount");
                change = 0;

                if (amount === null) 
                {
                    return;
                }

                if (!isNaN(amount) && amount != "") 
                {
                    if (parseFloat(amount) < parseFloat(t_total)) 
                    {
                        noty({
                            text: "Amount entered is less than total amount. [Click to dismiss]",
                            layout: "topRight",
                            type : "error"
                        })
                    }
                    else
                    {
                        change = parseFloat(amount) - parseFloat(t_total);

                        $.post("codeblooded/editDataManual", {

                            key : "t_id",
                            keyval : t_id,
                            table : "tbl_transactions",
                            t_amountgave : amount,
                            is_paid : 1,
                            date_paid : "<?php echo date('Y-m-d') ?>",
                            t_change : change,
                            user_id : <?php echo $_SESSION['user_id'] ?>

                        }, function(){

                            window.location.reload();

                        });
                    }
                }
                else
                {
                    noty({
                        text: "Invalid amount. [Click to dismiss]",
                        layout: "topRight",
                        type : "error"
                    })
                }
            }

            function delivered(t_id, value)
            {
                if (value == 0) 
                {
                    var input = "<i class='fa fa-times' style='cursor:pointer; color:red;' onclick='delivered("+ t_id +", 1)'></i>";
                }

                if (value == 1) 
                {
                    var input = "<i class='fa fa-check' style='cursor:pointer; color:green;' onclick='delivered("+ t_id +", 0)'></i>";
                }

                $.post("codeblooded/editDataManual", {

                    key : "t_id",
                    keyval : t_id,
                    table : "tbl_transactions",
                    is_delivered : value,
                    user_id : <?php echo $_SESSION['user_id'] ?>

                }, function(){

                    $("#delivered-"+t_id).html(input);

                });
            }

            function printReceipt(t_id)
            {
                <?php $url = explode("/", $_SERVER['REQUEST_URI']); ?>

                window.open("../<?php echo "../".$url[1]."/printReceipt?id="; ?>" + t_id, "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=10, left=50, width=350, height=" + window.screen.height/3*2.5);
            }

            function accountreceivable()
            {
                <?php $url = explode("/", $_SERVER['REQUEST_URI']); ?>

                window.open("../<?php echo "../".$url[1]."/accountreceivable"; ?>", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=10, left=50, width=800, height=" + window.screen.height/3*2.5);
            }

            function validate(evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                key = String.fromCharCode( key );
                var regex = /[0-9]|\./;
                if( !regex.test(key) ) {
                    theEvent.returnValue = false;
                    if(theEvent.preventDefault) theEvent.preventDefault();
                }
            }
        </script>       
    </body>
</html>






