<?php

    require('allen_pdf/WriteHTML.php');

    $pdf=new PDF_HTML();

    $pdf->FPDF1($orientation='l', $unit='mm', $size='letter');
    $pdf->setMargins(10, 10, 10);

    $pdf->AliasNbPages();
    $pdf->SetAutoPageBreak(true, 15);

    ///////////////////////////////////////////////////////////////////
    $codeblooded =& get_instance();
    $codeblooded->load->model('crud');

    extract($_GET);

    $rowsize = array(20, 25, 60, 15, 15, 55, 20, 20, 30);
    
    $pdf->SetFont('Arial', '', 12);

    $pdf->AddPage();
    $pdf->SetFont('Arial', 'b', 14);
    $pdf->Image("assets/theosLOGO.png", 60, 9, 100);
    $pdf->WriteHTML("<br><br><br><br><br>Ledger<br><br>");
    $pdf->SetFont('Arial', '', 12);

    $size = array(25, 60, 40, 50, 40, 30);

    $pdf->SetFont('Arial', 'b', 10);
    $pdf->writeTable(array(array("Date/Time", "Name", "Address", "Product / Qty", "Amount", "Paid")), $size);

    $pdf->SetFont('Arial', '', 10);

    $deliveriesQuery = $codeblooded->crud->getData(
                                            "tbl_transactions", 
                                            "is_delivery = 1 AND is_delivered = 0 ORDER BY t_date
                                        "); 

    $total_d = 0;
    $total_c = 0;               

    foreach ($deliveriesQuery['rows'] as $key) 
    {
        $name = $key->t_customer;
                                            $address = $key->t_address;

                                            $orders = array(); 

                                            $items = $codeblooded->crud->getData(
                                                "tbl_transaction_items ti, tbl_products p", 
                                                "ti.p_id = p.p_id AND ti.t_id = $key->t_id"
                                            )['rows'];

                                            foreach ($items as $i) 
                                            {
                                                array_push($orders, "$i->p_name ($i->qty * ". number_format($i->p_price, 2) ."php)");
                                            }

                                            if (!is_null($key->c_id) && $key->c_id != 0) 
                                            {
                                                $c = $codeblooded->crud->getData("tbl_customers", "c_id = $key->c_id")['rows'];
                                                $name = $c[0]->c_name." ".$c[0]->c_lastname;
                                                $address = $c[0]->c_address;
                                            }

                                            switch ($key->is_paid) 
                                            {
                                                case 0: $status = ""; break;
                                                case 1: $status = "Yes"; break;
                                            }

        $pdf->writeTable(array(
            array(
                date("m/d/Y", strtotime($key->t_date)), 
                $name, 
                $address, 
                implode(",\n", $orders), 
                number_format($key->t_total, 2), 
                $status
            )
        ), $size);
    }                      

    $pdf->Output();

?>