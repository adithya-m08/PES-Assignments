<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <div class="page-title">                    
                    <h2><span class="fa fa-lock"></span> User accounts</h2>
                </div>                   
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">                
                    
                    <div class="content-frame">
                        
                        <!-- START CONTENT FRAME TOP -->
                        <div class="content-frame-top">                        
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-9">
                                        <table class="table-condensed table-striped datatable" width="100%">
                                            <thead>
                                                <tr style="background:#fff">
                                                    <td><b>First Name</b></td>
                                                    <td><b>Middle Name</b></td>
                                                    <td><b>Last Name</b></td>
                                                    <td><b>E-mail</b></td>
                                                    <td><b>Contact No.</b></td>
                                                    <td width="50px"><b>Action</b></td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php $query = $codeblooded->crud->getData("tbl_users", "type = 'admin' AND is_deleted = 0"); ?>
                                            <?php foreach ($query['rows'] as $key): ?>
                                                <tr id="tr-<?php echo $key->user_id ?>" style="background:#fff" ondblclick="showEdit(<?php echo $key->user_id ?>)">
                                                    <td>
                                                        <span class="firstname-<?php echo $key->user_id ?>"><?php echo $key->firstname ?></span>
                                                        <input type="text" value="<?php echo $key->firstname ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->user_id ?>" id="firstname-<?php echo $key->user_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="middlename-<?php echo $key->user_id ?>"><?php echo $key->middlename ?></span>
                                                        <input type="text" value="<?php echo $key->middlename ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->user_id ?>" id="middlename-<?php echo $key->user_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="lastname-<?php echo $key->user_id ?>"><?php echo $key->lastname ?></span>
                                                        <input type="text" value="<?php echo $key->lastname ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->user_id ?>" id="lastname-<?php echo $key->user_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="email-<?php echo $key->user_id ?>"><?php echo $key->email ?></span>
                                                        <input type="text" value="<?php echo $key->email ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->user_id ?>" id="email-<?php echo $key->user_id ?>">
                                                    </td>
                                                    <td>
                                                        <span class="contact-<?php echo $key->user_id ?>"><?php echo $key->contact ?></span>
                                                        <input type="text" value="<?php echo $key->contact ?>" style="display:none"
                                                            class="form-control edit-<?php echo $key->user_id ?>" id="contact-<?php echo $key->user_id ?>">
                                                    </td>
                                                    <td align="right">
                                                        <ul class="panel-controls">
                                                            <li style="display:none" class="edit-<?php echo $key->user_id ?>" 
                                                                onclick="updateData(<?php echo $key->user_id ?>)">
                                                                <a href="#"><span class="fa fa-save"></span></a>
                                                            </li>
                                                            <li class="remove-<?php echo $key->user_id ?>" 
                                                                onclick="deleteData(<?php echo $key->user_id ?>)">
                                                                <a href="#"><span class="fa fa-times"></span></a>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                            <?php endforeach ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="3">
                                                        <i><b>Note : </b>Double click item to edit.</i>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <div class="col-md-3">
                                        <form method="POST" class="form-horizontal" id="add-form">
                                            <input type="hidden" name="table" value="tbl_users">
                                            <input type="hidden" name="type" value="admin">
                                            <div class="panel panel-default" style="background-color:#eee;">
                                                <div class="panel-body">
                                                    <h3 class="panel-title">Add Admin account</h3>
                                                </div>
                                                <div class="panel-body form-group-separated">
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">First Name</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="firstname" id="firstname">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Middle Name</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="middlename">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Family Name</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="lastname" id="lastname">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">E-Mail</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="email">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Contact No.</label>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" name="contact">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel-footer" style="background-color:#eee;">
                                                    <div class="col-md-12 col-xs-12">
                                                        <p><i><b>Note :</b> default username is <b>firstname+lastname</b> (i.e. juandelacruz), default password is <b>124567890</b></i></p>
                                                        <button type="button" class="btn btn-primary pull-right" onclick="addData()">Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>  
                        </div>
                        <!-- END CONTENT FRAME TOP -->
                        
                    </div>
                
                </div>
                <!-- PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <?php include "shared/js.php"; ?>
        <script type="text/javascript">
            // $("#filemaintenance, #useraccounts").addClass("active");

            function addData()
            {
                $("#add-form").append("<input type='hidden' name='username' value='"+ $("#firstname").val().toLowerCase()+""+$("#lastname").val().toLowerCase() +"'>");
                $("#add-form").append("<input type='hidden' name='password' value='<?php echo sha1('1234567890'); ?>'>");

                $.post("codeblooded/addDataManual", 

                    $("#add-form").serialize()

                ,function(data){

                    window.location.reload();

                });
            }

            function showEdit(user_id)
            {
                $(".student_number-"+user_id
                    +", .firstname-"+user_id
                    +", .middlename-"+user_id
                    +", .lastname-"+user_id
                    +", .email-"+user_id
                    +", .contact-"+user_id
                    +", .remove-"+user_id).css({ "display" : "none" });

                $(".edit-"+user_id).css({ "display" : "block" });
            }

            function updateData(user_id)
            {
                $.post("codeblooded/editDataManual", {

                    table : "tbl_users",
                    key : "user_id",
                    keyval : user_id,
                    student_number : $("#student_number-"+user_id).val(),
                    firstname : $("#firstname-"+user_id).val(),
                    middlename : $("#middlename-"+user_id).val(),
                    lastname : $("#lastname-"+user_id).val(),
                    email : $("#email-"+user_id).val(),
                    contact : $("#contact-"+user_id).val()

                }, function(data){

                    $(".student_number-"+user_id).html($("#student_number-"+user_id).val());
                    $(".firstname-"+user_id).html($("#firstname-"+user_id).val());
                    $(".middlename-"+user_id).html($("#middlename-"+user_id).val());
                    $(".lastname-"+user_id).html($("#lastname-"+user_id).val());
                    $(".email-"+user_id).html($("#email-"+user_id).val());
                    $(".contact-"+user_id).html($("#contact-"+user_id).val());

                    $(".student_number-"+user_id
                        +", .firstname-"+user_id
                        +", .middlename-"+user_id
                        +", .lastname-"+user_id
                        +", .email-"+user_id
                        +", .contact-"+user_id
                        +", .remove-"+user_id).css({ "display" : "block" });

                    $(".edit-"+user_id).css({ "display" : "none" });

                });
            }

            function deleteData(user_id)
            {
                noty({
                    text: 'Are you sure you want to delete this data?',
                    layout: 'topCenter',
                    buttons: [
                        {
                            addClass: 'btn btn-success btn-clean', text: 'Ok', onClick: function($noty) 
                            {
                                $noty.close();
                                    
                                $.post("codeblooded/editDataManual", {

                                    table : "tbl_users",
                                    key : "user_id",
                                    keyval : user_id,
                                    is_deleted : 1

                                }, function(data){

                                    $("#tr-"+user_id).remove();

                                });
                            }
                        },
                        {
                            addClass: 'btn btn-danger btn-clean', text: 'Cancel', onClick: function($noty) 
                            {
                                $noty.close();
                            }
                        }
                    ]
                }) 

            }
        </script>       
    </body>
</html>






