<!DOCTYPE html>
<html lang="en">
    <head>        
        <!-- META SECTION -->
        <title>Theos Water Refilling System</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
                
        <link rel="icon" href="assets/img/CBicon.png" type="image/x-icon" />
        <!-- END META SECTION -->
                
        <!-- CSS INCLUDE -->        
        <link rel="stylesheet" type="text/css" id="theme" href="assets/css/theme-default.css"/>
        <!-- EOF CSS INCLUDE -->                
    </head>
    <body>
                       
                        <!-- <div class="panel panel-default">
                            <div class="panel-body"> -->
                                <img src="assets/THEOSlogo.png" style="width: 50%; margin:10px auto; display:block;">
                                <table class="table-condensed table-bordered" width="100%">
                                    <thead>
                                        <tr>
                                            <td colspan="3" align="center">
                                                <label>ACCOUNT RECEIVABLE</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="text-align:center !important" width="33.33%">OR Number</th>
                                            <th style="text-align:center !important" width="33.33%">Name</th>
                                            <th style="text-align:right !important" width="33.33%">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 

                                        $codeblooded =& get_instance();
                                        $codeblooded->load->model("crud");

                                        $unpaidQuery = $codeblooded->crud->getData(
                                            "tbl_transactions", 
                                            "is_paid = 0 ORDER BY t_date
                                        ")['rows']; ?>

                                    <?php foreach ($unpaidQuery as $key): ?>
                                        <?php 
                                            $name = $key->t_customer;

                                            if (!is_null($key->c_id) && $key->c_id != 0) 
                                            {
                                                $c = $codeblooded->crud->getData("tbl_customers", "c_id = $key->c_id")['rows'];
                                                $name = $c[0]->c_name;
                                            }
                                        ?>

                                        <tr>
                                            <td align="center"><?php echo $key->t_ornumber ?></td>
                                            <td align="center"><?php echo $name ?></td>
                                            <td align="right"><?php echo number_format($key->t_total, 2) ?></td>
                                        </tr>
                                    <?php endforeach ?>
                                    </tbody>
                                </table>
                            <!-- </div>
                        </div> -->

    </body>
</html>

<script type="text/javascript">
    window.print();
</script>