<?php

    require('allen_pdf/WriteHTML.php');

    $pdf=new PDF_HTML();

    $pdf->FPDF1($orientation='p', $unit='mm', $size='letter');
    $pdf->setMargins(10, 10, 10);

    $pdf->AliasNbPages();
    $pdf->SetAutoPageBreak(true, 15);

    ///////////////////////////////////////////////////////////////////
    $codeblooded =& get_instance();
    $codeblooded->load->model('crud');

    $rowsize = array(20, 25, 60, 15, 15, 55, 20, 20, 30);
    
    $pdf->SetFont('Arial', '', 12);

    $pdf->AddPage();
    $pdf->SetFont('Arial', 'b', 14);
    $pdf->Image("assets/theosLOGO.png", 60, 9, 100);
    $pdf->WriteHTML("<br><br><br><br><br>Sales / Expenses Report<br><br>");
    $pdf->SetFont('Arial', '', 12);

    $size = array(25, 50, 25, 75, 25);

    $pdf->writeTable(array(array("", "SALES", "EXPENSES")), array(25, 75, 100));
    $pdf->SetFont('Arial', 'b', 10);
    $pdf->writeTable(array(array("Date", "Items", "Amount", "Remarks", "Amount")), $size);

    $pdf->SetFont('courier', 'b', 10);

    
    $period = new DatePeriod(
        new DateTime($_GET['from']),
        new DateInterval('P1D'),
        new DateTime($_GET['to'])
    );

    $barData = array();

    foreach ($period as $key => $value) 
    {
        $s = $codeblooded->crud->getData("tbl_transactions", "LEFT(t_date, 10) = '". $value->format('Y-m-d') ."' AND is_paid = 1");

        if ($s['total'] == 0) 
        {
            $barData[$value->format('Y-m-d')]['sales'] = 0;
            $barData[$value->format('Y-m-d')]['items'] = array();
        }
        else
        {
            $barData[$value->format('Y-m-d')]['sales'] = 0;
            $barData[$value->format('Y-m-d')]['items'] = array();

            foreach ($s['rows'] as $sales) 
            {
                $barData[$value->format('Y-m-d')]['sales'] += $sales->t_total;  

                $items = $codeblooded->crud->getData("tbl_transaction_items ti, tbl_products p", "ti.p_id = p.p_id AND ti.t_id = $sales->t_id")['rows'];

                foreach ($items as $i) 
                {
                    array_push($barData[$value->format('Y-m-d')]['items'], "$i->p_name ($i->qty)");
                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////

        $e = $codeblooded->crud->getData("tbl_expenses", "LEFT(e_date, 10) = '". $value->format('Y-m-d') ."'");

        if ($e['total'] == 0) 
        {
            $barData[$value->format('Y-m-d')]['expenses'] = 0;
            $barData[$value->format('Y-m-d')]['remarks'] = array();
        }
        else
        {
            $barData[$value->format('Y-m-d')]['expenses'] = 0;
            $barData[$value->format('Y-m-d')]['remarks'] = array();

            foreach ($e['rows'] as $expenses) 
            {
                $barData[$value->format('Y-m-d')]['expenses'] += $expenses->e_amount; 
                array_push($barData[$value->format('Y-m-d')]['remarks'], "$expenses->e_description (". number_format($expenses->e_amount, 2) .")");          
            }
        }

    }
                                                
    $barArray = array();

    foreach ($barData as $bd => $val) 
    {
        $pdf->writeTable(
            array(
                array(
                    date("m/d/Y", strtotime($bd)), 
                    implode("\n", $val['items']), 
                    number_format($val['sales'], 2), 
                    implode("\n", $val['remarks']),  
                    number_format($val['expenses'], 2)
                )
            ), 
            $size
        );
    }
                                            

    $pdf->Output();

?>