<?php

    require('allen_pdf/WriteHTML.php');

    $pdf=new PDF_HTML();

    $pdf->FPDF1($orientation='p', $unit='mm', $size='letter');
    $pdf->setMargins(10, 10, 10);

    $pdf->AliasNbPages();
    $pdf->SetAutoPageBreak(true, 15);

    ///////////////////////////////////////////////////////////////////
    $codeblooded =& get_instance();
    $codeblooded->load->model('crud');

    extract($_GET);

    $rowsize = array(20, 25, 60, 15, 15, 55, 20, 20, 30);
    
    $pdf->SetFont('Arial', '', 12);

    $customer = $codeblooded->crud->getData("tbl_customers", "c_id = $_GET[id]");
    $c = $customer['rows'][0];

    $pdf->AddPage();
    $pdf->SetFont('Arial', 'b', 14);
    $pdf->Image("assets/theosLOGO.png", 60, 9, 100);
    $pdf->WriteHTML("<br><br><br><br><br>$c->c_name $c->c_lastname<br><br>");
    $pdf->SetFont('Arial', '', 12);

    $size = array(25, 60, 25, 25, 25, 30);

    $pdf->SetFont('Arial', 'b', 10);
    $pdf->writeTable(array(array("Date", "Particulars", "Quantity", "Debit", "Credit", "Date Paid")), $size);

    $pdf->SetFont('Arial', '', 10);

    
    $ledgerQuery = $codeblooded->crud->getData(
        "tbl_transactions", 
        "c_id = $id ORDER BY t_date desc" //t_date between '$from' and '$to'
    ); 

    $total_d = 0;
    $total_c = 0;               

    foreach ($ledgerQuery['rows'] as $key) 
    {
        $orders = array(); 
        $qty = array(); 

        $items = $codeblooded->crud->getData(
            "tbl_transaction_items ti, tbl_products p", 
            "ti.p_id = p.p_id AND ti.t_id = $key->t_id"
        )['rows'];

        $debit = 0;
        $credit = 0;
        $date_paid = "";

        if (!is_null($key->date_paid)) {
            $date_paid = date('m/d/Y', strtotime($key->date_paid));
        }

        if ($key->is_paid == 0) 
        {
            $debit = "";
            $credit = number_format($key->t_total, 2);

            $total_c += $key->t_total;
        }
        else
        {
            if (is_null($key->date_paid)) 
            {
                $debit = number_format($key->t_total, 2);
                $credit = "";

                $total_d += $key->t_total;
            }
            else
            {
                $debit = "";
                $credit = number_format($key->t_total, 2);   

                $total_c += $key->t_total;
            }
        }

        foreach ($items as $i) 
        {
            array_push($orders, "$i->p_name");
            array_push($qty, "$i->qty");
        }

        $pdf->writeTable(array(
            array(
                date("m/d/Y", strtotime($key->t_date)), 
                implode(",\n", $orders), 
                implode(",\n", $qty), 
                $debit, 
                $credit,
                $date_paid
            )
        ), $size);
    }                      

    $pdf->Output();

?>