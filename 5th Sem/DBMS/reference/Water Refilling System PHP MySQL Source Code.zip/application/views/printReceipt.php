<?php

    require('allen_pdf/WriteHTML.php');

    $pdf=new PDF_HTML();

    $pdf->FPDF1($orientation='p', $unit='mm', $size=array(100, 150));
    $pdf->setMargins(10, 10, 10);

    $pdf->AliasNbPages();
    $pdf->SetAutoPageBreak(true, 15);

    ///////////////////////////////////////////////////////////////////
    $codeblooded =& get_instance();
    $codeblooded->load->model('crud');
    
    extract($_GET);

    $trans = $codeblooded->crud->getData("tbl_transactions", "t_id = $id")['rows'][0];

    $items = array();

    $trans_items = $codeblooded->crud->getData("tbl_transaction_items ti, tbl_products p", "ti.t_id = $id AND ti.p_id = p.p_id")['rows'];

    foreach ($trans_items as $key) 
    {
        array_push($items, $key);
    }

    $pdf->SetFont('Arial', '', 12);

    $pdf->AddPage();
    $pdf->SetFont('Arial', 'b', 14);
    $pdf->Image("assets/theoslogo.png", 15, 9, 70);

    $pdf->WriteHTML("<br><br><br>");
    $pdf->SetFont('arial', 'b', 12);

    $pdf->cell(70);
    $pdf->WriteHTML("$trans->t_ornumber<br>");

    $pdf->SetFont('arial', '', 10);    

    foreach ($items as $key) 
    {
        $pdf->WriteHTML("$key->p_name<br>");
        $pdf->cell(30);
        $pdf->WriteHTML("$key->qty     x      $key->price           ". number_format(($key->price*$key->qty), 2) ."<br>");
    }

    $pdf->SetFont('arial', '', 10);    
    $pdf->WriteHTML("<br>TOTAL");
    $pdf->cell(50);
    $pdf->WriteHTML(number_format($trans->t_total, 2));

    $pdf->WriteHTML("<br>Amount paid");
    $pdf->cell(42);
    $pdf->WriteHTML(number_format($trans->t_amountgave, 2));

    $pdf->WriteHTML("<br>Change");
    $pdf->cell(49);
    $pdf->WriteHTML(number_format($trans->t_change, 2));

    $pdf->Output();

?>