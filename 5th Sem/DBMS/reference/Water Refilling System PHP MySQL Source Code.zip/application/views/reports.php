<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb push-down-0">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <div class="content-frame">
                    
                    <!-- START CONTENT FRAME TOP -->
                    <div class="content-frame-top">                        
                        <div class="page-title">                    
                            <h2><span class="fa fa-folder-open"></span> Sales / Expenses Report</h2>
                        </div>                                      
                        <div class="pull-right">
                            <button class="btn btn-default content-frame-left-toggle"><span class="fa fa-bars"></span></button>
                        </div>                        
                    </div>
                    <!-- END CONTENT FRAME TOP -->
                    
                    <!-- START CONTENT FRAME LEFT -->
                    <div class="content-frame-left">
                        
                        <form method="POST">
                            <table class="table-condensed" width="100%">
                                <tr>
                                    <td>
                                        <label>From</label>
                                        <input type="date" class="form-control" name="from" id="from" 
                                        value="<?php if(isset($_POST['from'])){ echo $_POST['from']; }else{ echo date('Y-m-d'); } ?>"><!--onchange="$('#to').val(this.value)"-->
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label>To</label>
                                        <input type="date" class="form-control" name="to" id="to"
                                        value="<?php if(isset($_POST['to'])){ echo $_POST['to']; }else{ echo date('Y-m-d'); } ?>">
                                    </td>
                                </tr>
                                <tr>
                                    <td align="right">
                                        <button class="btn btn-primary">
                                            Generate Report
                                        </button>
                                    </td>
                                </tr>
                            </table>
                        </form>

                    </div>
                    <!-- END CONTENT FRAME LEFT -->
                    
                    <!-- START CONTENT FRAME BODY -->
                    <div class="content-frame-body" style="padding:0">
                        
                        <?php 
                            if (!isset($_POST['from'])) 
                            {
                                $from = date("Y-m-d");
                                // $to = date("Y-m-d");
                                $to = date("Y-m-d", strtotime("+1 day"));
                            }
                            else
                            {
                                $from = $_POST['from'];
                                // $to = $_POST['to'];
                                $to = date("Y-m-d", strtotime($_POST['to']." +1 day"));
                            }
                        ?>

                        <!-- PAGE CONTENT TABBED -->
                        <div class="page-tabs">
                            <a href="#third-tab">Ledger</a>
                            <a href="#first-tab">Tabular</a>
                            <a href="#second-tab" class="active">Graphical</a>
                        </div>
                        
                        <div class="page-content-wrap page-tabs-item" id="first-tab">
                        
                            <div class="row">
                                <div class="col-md-12">
                                    <button class="btn btn-default pull-right" onclick="printReport()"><i class="fa fa-print"></i> PRINT</button>
                                    <hr>
                                </div>
                                <div class="col-md-6">
                                    <div class="panel panel-default" style="border-radius:0">
                                        <div class="panel-body">
                                            <h3 class="panel-title">Sales</h3>
                                            <table class="table table-condensed table-bordered datatable">
                                                <thead>
                                                    <tr>
                                                        <th width="30%">Date</th>
                                                        <th width="30%">Customer</th>
                                                        <th width="40%">Product(s)</th>
                                                        <th width="30%">Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php 
                                                    $totalSales = 0; 
                                                    $totalUnpaid = 0;
                                                    $salesQuery = $codeblooded->crud->getData(
                                                        "tbl_transactions", 
                                                        "is_paid = 1 AND t_date between '$from' and '$to' ORDER BY t_date"
                                                    ); 

                                                    $unpaidQuery = $codeblooded->crud->getData(
                                                        "tbl_transactions", 
                                                        "is_paid = 0 AND t_date between '$from' and '$to' ORDER BY t_date"
                                                    ); 

                                                    foreach ($unpaidQuery['rows'] as $up) 
                                                    {
                                                        $totalUnpaid += $up->t_total;
                                                    }
                                                ?>
                                                
                                                <?php foreach ($salesQuery['rows'] as $key): ?>

                                                    <?php 

                                                        $customer = strtoupper($key->t_customer);

                                                        if (!is_null($key->c_id) && $key->c_id != 0) 
                                                        {
                                                            $customerQuery = $codeblooded->crud->getData("tbl_customers", "c_id = $key->c_id");

                                                            if ($customerQuery['total'] != 0) 
                                                            {
                                                                $customer = strtoupper($customerQuery['rows'][0]->c_name." ".$customerQuery['rows'][0]->c_lastname);
                                                            }

                                                        }

                                                        $orders = array(); 

                                                        $items = $codeblooded->crud->getData(
                                                            "tbl_transaction_items ti, tbl_products p", 
                                                            "ti.p_id = p.p_id AND ti.t_id = $key->t_id"
                                                        )['rows'];

                                                        foreach ($items as $i) 
                                                        {
                                                            array_push($orders, "$i->p_name ($i->qty)");
                                                        }
                                                    ?>

                                                    <tr>
                                                        <td><?php echo date("m/d/Y", strtotime($key->t_date)) ?></td>
                                                        <td><?php echo $customer ?></td>
                                                        <td><?php echo implode("<br>", $orders) ?></td>
                                                        <td><?php echo number_format($key->t_total ,2) ?></td>
                                                    </tr>
                                                    <?php $totalSales += $key->t_total; ?>
                                                <?php endforeach ?>  

                                                <?php foreach ($unpaidQuery['rows'] as $key): ?>

                                                    <?php 

                                                        $customer = strtoupper($key->t_customer);

                                                        if (!is_null($key->c_id) && $key->c_id != 0) 
                                                        {
                                                            $customerQuery = $codeblooded->crud->getData("tbl_customers", "c_id = $key->c_id")['rows'];

                                                            $customer = strtoupper($customerQuery[0]->c_name." ".$customerQuery[0]->c_lastname);
                                                        }

                                                        $orders = array(); 

                                                        $items = $codeblooded->crud->getData(
                                                            "tbl_transaction_items ti, tbl_products p", 
                                                            "ti.p_id = p.p_id AND ti.t_id = $key->t_id"
                                                        )['rows'];

                                                        foreach ($items as $i) 
                                                        {
                                                            array_push($orders, "$i->p_name ($i->qty)");
                                                        }
                                                    ?>

                                                    <tr>
                                                        <td><?php echo date("m/d/Y", strtotime($key->t_date)) ?></td>
                                                        <td><?php echo $customer ?></td>
                                                        <td><?php echo implode("<br>", $orders) ?></td>
                                                        <td><?php echo number_format($key->t_total ,2) ?> <small><i>Unpaid</i></small></td>
                                                    </tr>
                                                    <?php $totalSales += $key->t_total; ?>
                                                <?php endforeach ?>  
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="3" align="right"><b>TOTAL</b></td>
                                                        <td style="font-weight:900; color:green;"><?php echo number_format($totalSales, 2) ?></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="panel panel-default" style="border-radius:0">
                                        <div class="panel-body">
                                            <h3 class="panel-title">Expenses</h3>
                                            <table class="table table-condensed table-bordered datatable">
                                                <thead>
                                                    <tr>
                                                        <th width="30%">Date</th>
                                                        <th width="40%">Remarks</th>
                                                        <th width="30%">Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php $totalExpenses = 0; $expensesQuery = $codeblooded->crud->getData("tbl_expenses", "e_date between '$from' and '$to' ORDER BY e_date"); ?>
                                                <?php foreach ($expensesQuery['rows'] as $key): ?>
                                                    <tr>
                                                        <td><?php echo date("m/d/Y", strtotime($key->e_date)) ?></td>
                                                        <td><?php echo $key->e_description; ?></td>
                                                        <td><?php echo number_format($key->e_amount ,2) ?></td>
                                                    </tr>
                                                    <?php $totalExpenses += $key->e_amount ?>
                                                <?php endforeach ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="2" align="right"><b>TOTAL</b></td>
                                                        <td style="font-weight:900; color:red;"><?php echo number_format($totalExpenses, 2) ?></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        </div>
                        <div class="page-content-wrap page-tabs-item active" id="second-tab">
                        
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <div id="morris-donut" style="height: 300px;"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-9">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <div id="morris-bar" style="height: 300px;"></div>
                                        
                                            <?php 
                                                $period = new DatePeriod(
                                                    new DateTime($from),
                                                    new DateInterval('P1D'),
                                                    new DateTime($to)
                                                );

                                                $barData = array();

                                                foreach ($period as $key => $value) 
                                                {
                                                    $s = $codeblooded->crud->getData("tbl_transactions", "LEFT(t_date, 10) = '". $value->format('Y-m-d') ."'");

                                                    if ($s['total'] == 0) 
                                                    {
                                                        $barData[$value->format('Y-m-d')]['sales'] = 0;
                                                        $barData[$value->format('Y-m-d')]['unpaid'] = 0;
                                                    }
                                                    else
                                                    {
                                                        $barData[$value->format('Y-m-d')]['sales'] = 0;
                                                        $barData[$value->format('Y-m-d')]['unpaid'] = 0;

                                                        foreach ($s['rows'] as $sales) 
                                                        {
                                                            if ($sales->is_paid == 1) 
                                                            {
                                                                $barData[$value->format('Y-m-d')]['sales'] += $sales->t_total;    
                                                            }
                                                            else
                                                            {
                                                                $barData[$value->format('Y-m-d')]['unpaid'] += $sales->t_total;    
                                                            }
                                                        }
                                                    }

                                                    //////////////////////////////////////////////////////////////////////////////////////////
                                                    //////////////////////////////////////////////////////////////////////////////////////////
                                                    //////////////////////////////////////////////////////////////////////////////////////////

                                                    $e = $codeblooded->crud->getData("tbl_expenses", "LEFT(e_date, 10) = '". $value->format('Y-m-d') ."'");

                                                    if ($e['total'] == 0) 
                                                    {
                                                        $barData[$value->format('Y-m-d')]['expenses'] = 0;
                                                    }
                                                    else
                                                    {
                                                        $barData[$value->format('Y-m-d')]['expenses'] = 0;

                                                        foreach ($e['rows'] as $expenses) 
                                                        {
                                                            $barData[$value->format('Y-m-d')]['expenses'] += $expenses->e_amount;           
                                                        }
                                                    }

                                                }
                                                
                                                $barArray = array();

                                                foreach ($barData as $bd => $val) 
                                                {
                                                    array_push(
                                                        $barArray, 
                                                        "{ y: '". date("Y-m-d", strtotime($bd)) ."', a: $val[sales], b: $val[expenses], c: $val[unpaid] }"
                                                    );
                                                }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        </div>
                        <div class="page-content-wrap page-tabs-item" id="third-tab">
                                
                            <div class="row">
                                <div class="col-md-12">
                                    <button class="btn btn-default pull-right" onclick="printLedger()"><i class="fa fa-print"></i> PRINT</button>
                                    <hr>
                                </div>

                                <div class="col-md-12">
                                    
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <table class="table-condensed table-bordered datatable" width="100%">
                                                <thead>
                                                    <tr>
                                                        <td><b>Date</b></td>
                                                        <td><b>Particular(s)</b></td>
                                                        <td><b>Quantity</b></td>
                                                        <td><b>Debit</b></td>
                                                        <td><b>Credit</b></td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                        $ledgerQuery = $codeblooded->crud->getData(
                                                            "tbl_transactions", 
                                                             "t_date between '$from' and '$to' ORDER BY t_date"
                                                        ); 

                                                        $total_d = 0;
                                                        $total_c = 0;
                                                    ?>
                                                        
                                                    <?php foreach ($ledgerQuery['rows'] as $key): ?>

                                                        <?php 
                                                            $orders = array(); 
                                                            $qty = array(); 

                                                            $items = $codeblooded->crud->getData(
                                                                "tbl_transaction_items ti, tbl_products p", 
                                                                "ti.p_id = p.p_id AND ti.t_id = $key->t_id"
                                                            )['rows'];

                                                            $debit = 0;
                                                            $credit = 0;

                                                            if ($key->is_paid == 0) 
                                                            {
                                                                $debit = "";
                                                                $credit = number_format($key->t_total, 2);

                                                                $total_c += $key->t_total;
                                                            }
                                                            else
                                                            {
                                                                if (is_null($key->date_paid)) 
                                                                {
                                                                    $debit = number_format($key->t_total, 2);
                                                                    $credit = "";

                                                                    $total_d += $key->t_total;
                                                                }
                                                                else
                                                                {
                                                                    $debit = "";
                                                                    $credit = number_format($key->t_total, 2) . " <i>(Paid : ". date('m/d/Y', strtotime($key->date_paid)) .")</i>";   

                                                                    $total_c += $key->t_total;
                                                                }
                                                            }

                                                            foreach ($items as $i) 
                                                            {
                                                                array_push($orders, "$i->p_name");
                                                                array_push($qty, "$i->qty");
                                                            }
                                                        ?>

                                                        <tr>
                                                            <td><?php echo date("m/d/Y", strtotime($key->t_date)) ?></td>
                                                            <td><?php echo implode(",<br>", $orders) ?></td>
                                                            <td><?php echo implode(",<br>", $qty) ?></td>
                                                            <td><?php echo $debit ?></td>
                                                            <td><?php echo $credit ?></td>
                                                        </tr>
                                                    <?php endforeach ?>  
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td style="font-weight:900" colspan="3" align="right">TOTAL</td>
                                                        <td style="font-weight:900"><?php echo number_format($total_d, 2); ?></td>
                                                        <td style="font-weight:900"><?php echo number_format($total_c, 2); ?></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- END PAGE CONTENT TABBED -->

                    </div>
                    <!-- END CONTENT FRAME BODY -->
                </div>

            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <?php include "shared/js.php"; ?>

        <script type="text/javascript" src="assets/js/plugins/morris/raphael-min.js"></script>
        <script type="text/javascript" src="assets/js/plugins/morris/morris.min.js"></script>

        <script type="text/javascript">
            $("#reports").addClass("active");

            // Morris.Bar({
            // Morris.Line({
            //     element: 'morris-bar',
            //     data: [
            //         <?php echo implode(", ", $barArray); ?>
            //     ],
            //     xkey: 'y',
            //     ykeys: ['a', 'b', 'c'],
            //     labels: ['Sales', 'Expenses', 'Unpaid'],
            //     // barColors: ['green', 'red', 'orange']
            //     lineColors: ['green', 'red', 'orange']
            // });

            Morris.Line({
              element: 'morris-bar',
              data: [
                <?php echo implode(", ", $barArray); ?>
              ],
              xkey: 'y',
              ykeys: ['a', 'b', 'c'],
              labels: ['Sales', 'Expenses', 'Unpaid'],
              resize: true,
              lineColors: ['green', 'red', 'orange']
            });

             Morris.Donut({
                element: 'morris-donut',
                data: [
                    {label: "Sales", value: <?php echo $totalSales ?>},
                    {label: "Expenses", value: <?php echo $totalExpenses ?>},
                    {label: "Unpaid", value: <?php echo $totalUnpaid ?>}
                ],
                colors: ['green', 'red', 'orange']
            });


            function validate(evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                key = String.fromCharCode( key );
                var regex = /[0-9]|\./;
                if( !regex.test(key) ) {
                    theEvent.returnValue = false;
                    if(theEvent.preventDefault) theEvent.preventDefault();
                }
            }

            function printLedger()
            {
                <?php $url = explode("/", $_SERVER['REQUEST_URI']); ?>

                window.open("../<?php echo "../".$url[1]."/printledger?from=$from&to=$to"; ?>", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=10, left=50, width=800, height=" + window.screen.height/3*2.5);
            }

            function printReport()
            {
                <?php $url = explode("/", $_SERVER['REQUEST_URI']); ?>

                window.open("../<?php echo "../".$url[1]."/printreport?from=$from&to=$to"; ?>", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=10, left=50, width=800, height=" + window.screen.height/3*2.5);
            }
        </script>       
    </body>
</html>






