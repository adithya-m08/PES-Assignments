<?php include "shared/session.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>        
        <?php include 'shared/head.php'; ?>                
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top page-navigation-top-custom">            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START PAGE CONTENT HEADER -->
                <?php include "shared/topnavbar.php"; ?>
                <!-- END PAGE CONTENT HEADER -->
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include "shared/sidebar.php"; ?>  
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb push-down-0">
                    <li><a href="#"><?php echo strtoupper(end($url)); ?></a></li>
                </ul>
                <!-- END BREADCRUMB -->                
                
                <div class="content-frame">
                    
                    <!-- START CONTENT FRAME TOP -->
                    <div class="content-frame-top">                        
                        <div class="page-title">                    
                            <h2><span class="fa fa-truck"></span> Deliveries</h2>
                        </div>                                      
                        <div class="pull-right">
                            <button class="btn btn-default content-frame-left-toggle"><span class="fa fa-bars"></span></button>
                        </div>                        
                    </div>
                    <!-- END CONTENT FRAME TOP -->
                    
                    <!-- START CONTENT FRAME RIGHT -->
                    <div class="content-frame-right">
                        
                    </div>
                    <!-- END CONTENT FRAME RIGHT -->
                    
                    <!-- START CONTENT FRAME BODY -->
                    <div class="content-frame-body content-frame-body-left">
                        
                        <div class="panel panel-default" style="border-radius:0">
                            <div class="panel-body">
                                <button class="btn btn-default pull-right" style="margin-bottom:10px" onclick="printDeliveries()">
                                    <i class="fa fa-print"></i> PRINT
                                </button>

                                <table class="table-condensed table-striped datatable" width="100%">
                                    <thead>
                                        <tr>
                                            <th style="text-align:center !important" width="15%">Date/Time Ordered</th>
                                            <th style="text-align:center !important" width="15%">Name</th>
                                            <th style="text-align:center !important" width="15%">Address</th>
                                            <th style="text-align:center !important" width="15%">Product / Quantity</th>
                                            <th style="text-align:right !important" width="15%">Amount</th>
                                            <th style="text-align:center !important" width="15%">Paid</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 

                                        $deliveriesQuery = $codeblooded->crud->getData(
                                            "tbl_transactions", 
                                            "is_delivery = 1 AND is_delivered = 0 ORDER BY t_date
                                        ")['rows']; ?>

                                    <?php foreach ($deliveriesQuery as $key): ?>
                                        <?php 
                                            $name = $key->t_customer;
                                            $address = $key->t_address;

                                            $orders = array(); 

                                            $items = $codeblooded->crud->getData(
                                                "tbl_transaction_items ti, tbl_products p", 
                                                "ti.p_id = p.p_id AND ti.t_id = $key->t_id"
                                            )['rows'];

                                            foreach ($items as $i) 
                                            {
                                                array_push($orders, "$i->p_name ($i->qty * ". number_format($i->price, 2) ."php)");
                                            }

                                            if (!is_null($key->c_id) && $key->c_id != 0) 
                                            {
                                                $c = $codeblooded->crud->getData("tbl_customers", "c_id = $key->c_id")['rows'];
                                                $name = $c[0]->c_name." ".$c[0]->c_lastname;
                                                $address = $c[0]->c_address;
                                            }

                                            switch ($key->is_paid) 
                                            {
                                                case 0: $status = ""; break;
                                                case 1: $status = "<i class='fa fa-2x fa-check' style='color:green'></i>"; break;
                                            }
                                        ?>

                                        <tr>
                                            <td align="center"><?php echo date("m/d/Y, h:iA", strtotime($key->t_date)) ?></td>
                                            <td align="center"><?php echo $name ?></td>
                                            <td align="center"><?php echo $address ?></td>
                                            <td align="center"><?php echo implode("<br>", $orders) ?></td>
                                            <td align="right"><?php echo number_format($key->t_total, 2) ?></td>
                                            <td align="center"><?php echo $status ?></td>
                                        </tr>
                                    <?php endforeach ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- END CONTENT FRAME BODY -->
                </div>

            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <?php include "shared/js.php"; ?>
        <script type="text/javascript">
            $("#deliveries").addClass("active");

            function addExpenses()
            {
                if (!codeblooded.validateForm('expenses-form')) 
                {
                    return;
                }

                $("#expenses-form").submit();
            }

            function validate(evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                key = String.fromCharCode( key );
                var regex = /[0-9]|\./;
                if( !regex.test(key) ) {
                    theEvent.returnValue = false;
                    if(theEvent.preventDefault) theEvent.preventDefault();
                }
            }

            function printDeliveries()
            {
                <?php $url = explode("/", $_SERVER['REQUEST_URI']); ?>

                window.open("../<?php echo "../".$url[1]."/printdeliveries"; ?>", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=10, left=50, width=800, height=" + window.screen.height/3*2.5);
            }
        </script>       
    </body>
</html>






