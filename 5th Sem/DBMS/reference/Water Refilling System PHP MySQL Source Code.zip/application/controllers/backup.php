<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 * 
 * @extends CI_Controller
 */
class backup extends CI_Controller {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		parent::__construct();
		$this->load->model('crud');
	
		date_default_timezone_set("Asia/Manila");	
	}
	
	public function index() 
	{
		$this->load->view('backup');
	}

	function createBackup()
	{
		$this->load->dbutil();   
       	$backup =& $this->dbutil->backup();

        $db_name = 'backup-'. date("Y-m-d-H-i-s") .'.sql';
        $save = "assets/database_backup/$db_name";

        $this->load->helper('file');
        write_file($save, $backup); 


        $this->load->helper('download');
        // force_download($db_name, $backup); 

         $this->crud->addData(
        	"tbl_database_backups",
        	array(
        		"dbb_date"=>date("Y-m-d H:i:s"),
        		"dbb_file"=>$db_name,
        		"user_id"=>$_POST['user_id']
        	)
        );
	}

}