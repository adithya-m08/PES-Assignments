<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 * 
 * @extends CI_Controller
 */
class customers extends CI_Controller {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		parent::__construct();
		$this->load->model('crud');
	
		date_default_timezone_set("Asia/Manila");	
	}
	
	public function index() 
	{
		$this->load->view('customers');
	}

	function updateAccount()
	{
		$this->crud->editData(
			"user_id",
			$_POST['user_id'],
			"tbl_users", 
			array(
				"username"=>$_POST['username'],
				"password"=>sha1($_POST['password'])
			)
		); 
	}

}