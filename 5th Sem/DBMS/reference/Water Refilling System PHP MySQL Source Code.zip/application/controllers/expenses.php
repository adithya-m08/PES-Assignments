<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 * 
 * @extends CI_Controller
 */
class expenses extends CI_Controller {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		parent::__construct();
		$this->load->model('crud');
	
		date_default_timezone_set("Asia/Manila");	
	}
	
	public function index() 
	{
		$this->load->view('expenses');
	}

	function addExpenses()
	{
		$name = $_FILES['e_receipt']['name'];
		$extension = explode('.', $name);
		$extension = end($extension);
		$random_name = rand().rand().rand();
		$tmp = $_FILES['e_receipt']['tmp_name'];
					                
		$source = $tmp;
		$dest = "assets/images/receipts/$random_name.$extension";
		$x = copy($source, $dest);
		$_POST['e_receipt'] = "$random_name.$extension";

		$user_id = $_POST['user_id'];
		unset($_POST['user_id']);

		$add = $this->crud->addData("tbl_expenses", $_POST);

		$this->crud->addData("tbl_logs", 
			array(
				"user_id"=>$user_id,
				"log_date"=>date("Y-m-d H:i:s"),
				"log_remarks"=>"Added ". json_encode($_POST) . " ($add[ret_id]) in tbl_expenses",
			)
		);

		header("Location:../expenses");
	}

}