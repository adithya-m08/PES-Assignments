<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 * 
 * @extends CI_Controller
 */
class admin extends CI_Controller {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		parent::__construct();
		$this->load->model('crud');
	
		date_default_timezone_set("Asia/Manila");	
	}
	
	public function index() 
	{
		$this->load->view('admin');
	}

	function checkSignIn()
	{
		extract($_POST);

		$query = $this->crud->getData("tbl_users", "username = '$username' AND is_deleted = 0");

		if ($query['total'] == 0) 
		{
			$result['error'] = true;
			$result['message'] = "Invalid username.";
		}
		else
		{
			if (sha1($password) != $query['rows'][0]->password) 
			{
				$result['error'] = true;
				$result['message'] = "Incorrect password.";		
			}
			else
			{
				$result['error'] = false;

				session_start();

				$_SESSION['user_id'] = $query['rows'][0]->user_id;
			}
		}

		echo json_encode($result);
	}

	function signout()
	{
		session_start();

		if (isset($_SESSION['user_id'])) 
		{
			session_destroy();
		}

		header("location:../admin");
	}

}