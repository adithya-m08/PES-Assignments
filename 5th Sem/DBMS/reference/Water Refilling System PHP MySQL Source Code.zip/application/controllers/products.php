<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 * 
 * @extends CI_Controller
 */
class products extends CI_Controller {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		parent::__construct();
		$this->load->model('crud');
	
		date_default_timezone_set("Asia/Manila");	
	}
	
	public function index() 
	{
		$this->load->view('products');
	}

	function updateAccount()
	{
		$this->crud->editData(
			"user_id",
			$_POST['user_id'],
			"tbl_users", 
			array(
				"username"=>$_POST['username'],
				"password"=>sha1($_POST['password'])
			)
		); 
	}

	function addStock()
	{
		extract($_POST);

		for ($i = 0; $i < $val; $i++) 
		{ 
			$this->crud->addData("tbl_product_inventory", array( "p_id"=>$p_id, "pi_item_code"=>rand().rand() ));
		}
	}
}