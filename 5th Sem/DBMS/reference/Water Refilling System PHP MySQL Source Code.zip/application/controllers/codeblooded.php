<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class codeblooded extends CI_Controller{

	private $model;
	private $model_name = 'crud';
	
	function __construct()
	{
		parent::__construct();
		
		//SET MODEL HERE
		$this->load->model($this->model_name);
		$this->model = $this->crud;
	}

	function getData()
	{
		$model = $this->model;

		$data = array();
		$btn = array();

		extract($_POST);

		$total = $this->crud->getData($table, "$condition AND $searchkey LIKE '%$search%'")['total'];
		$branches = $this->crud->getData($table, "$condition AND $searchkey LIKE '%$search%' ORDER BY $searchkey LIMIT $limit OFFSET $offset")['rows'];

		$count = $offset;

		foreach ($branches as $key) 
		{
			array_push($data, $key);
			$count++;
		}

		if ($total%$limit == 0) 
		{
			$pages = $total/$limit;
		}
		else
		{
			$pages = $total/$limit;
			$p = explode(".", $pages);
			$pages = $p[0]+1;
		}

		for ($i = 1; $i <= $pages; $i++) 
		{ 
			array_push($btn, array("pagenumber"=>$i, "offset"=>($i-1)*$limit));
		}

		if ($total == 0) 
		{
			$label = "0 - 0 / 0";
		}
		else
		{
			$label = ($offset+1) ." - ". ($count) ." / ". $total;
		}

		$result['btn'] = $btn;
		$result['data'] = $data;
		$result['totalpages'] = $pages;
		$result['label'] = $label;

		echo json_encode($result);
	}

	function addData()
	{
		$model = $this->model;

		$table = $_POST['table'];

		unset($_POST['table']);

		$data = $_POST;

		$add = $this->crud->addData($table, $data);

		echo json_encode($add);
	}

	function addDataManual()
	{
		$model = $this->model;

		$table = $_POST['table'];
		$user_id = $_POST['user_id'];

		unset($_POST['table']);
		unset($_POST['user_id']);

		$data = $_POST;

		$add = $this->crud->addData($table, $data);

		$this->crud->addData("tbl_logs", 
			array(
				"user_id"=>$user_id,
				"log_date"=>date("Y-m-d H:i:s"),
				"log_remarks"=>"Added ". json_encode($data) . " ($add[ret_id]) in $table",
			)
		);
	}

	function editData()
	{
		$model = $this->model;

		$table = $_POST['table'];
		$key = $_POST['key'];
		$keyval = $_POST['keyval'];

		unset($_POST['table']);
		unset($_POST['key']);
		unset($_POST['keyval']);

		$data = $_POST;

		$this->crud->editData($key, $keyval, $table, $data);

		// echo json_encode($_POST);
	}

	function editDataManual()
	{
		$model = $this->model;

		$table = $_POST['table'];
		$key = $_POST['key'];
		$keyval = $_POST['keyval'];
		$user_id = $_POST['user_id'];

		unset($_POST['table']);
		unset($_POST['key']);
		unset($_POST['keyval']);
		unset($_POST['user_id']);

		$data = $_POST;

		$this->crud->editData($key, $keyval, $table, $data);

		$this->crud->addData("tbl_logs", 
			array(
				"user_id"=>$user_id,
				"log_date"=>date("Y-m-d H:i:s"),
				"log_remarks"=>"Updated ". json_encode($data) ." ($key:$keyval) in $table"
			)
		);
	}

	function getDataByID()
	{
		$model = $this->model;

		$data = $this->crud->getData($_POST['table'], $_POST['condition'])['rows'];
		
		echo json_encode($data);
	}

	function getTotalData()
	{
		$model = $this->model;

		$data = $this->crud->getData($_POST['table'], $_POST['condition'])['total'];
		
		echo json_encode($data);
	}

	function deleteData()
	{
		$model = $this->model;

		$this->crud->deleteData($_POST['table'], $_POST['condition']);		
	}

	function deleteDataManual()
	{
		$model = $this->model;

		$user_id = $_POST['user_id'];
		$table = $_POST['table'];
		$key = $_POST['key'];
		$keyval = $_POST['keyval'];

		unset($_POST['user_id']);
		unset($_POST['table']);
		unset($_POST['key']);
		unset($_POST['keyval']);

		$data = $_POST;

		$this->crud->editData($key, $keyval, $table, array("is_deleted"=>1));

		$this->crud->addData("tbl_logs", 
			array(
				"user_id"=>$user_id,
				"log_date"=>date("Y-m-d H:i:s"),
				"log_remarks"=>"Deleted $key : $keyval in $table"
			)
		);
	}
}