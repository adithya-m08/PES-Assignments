<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 * 
 * @extends CI_Controller
 */
class accountreceivable extends CI_Controller {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		parent::__construct();
		$this->load->model('crud');
	
		date_default_timezone_set("Asia/Manila");	
	}
	
	public function index() 
	{
		$this->load->view('accountreceivable');
	}

}