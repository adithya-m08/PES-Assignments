<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 * 
 * @extends CI_Controller
 */
class transactions extends CI_Controller {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		parent::__construct();
		$this->load->model('crud');
	
		date_default_timezone_set("Asia/Manila");	
	}
	
	public function index() 
	{
		$this->load->view('transactions');
	}

	function getTotalAmount()
	{
		$total = 0;

		if (isset($_POST['p_id']))
		{
			foreach ($_POST['p_id'] as $key) 
			{
				$query = $this->crud->getData("tbl_products", "p_id = $key")['rows'];

				$total += $query[0]->p_price * $_POST['qty'][$key];
			}
		}


		$result['total'] = $total;

		echo json_encode($result);
	}

	function addTransaction()
	{
		$result['error'] = false;
		$result['message'] = "";

		$items = array();

		$_POST['t_date'] = date("Y-m-d H:i:s");

		if ($_POST['t_amountgave'] != 0 && $_POST['t_amountgave'] != "0.00") 
		{
			$_POST['is_paid'] = 1;
		}

		$check = $this->crud->getData("tbl_transactions", "t_ornumber = '$_POST[t_ornumber]'")['total'];

		if ($check != 0) 
		{
			$result['error'] = true; 
				$result['message'] = "Duplicate OR NUMBER.";
		}
		else
		{
			if (!isset($_POST['p_id'])) 
			{ 
				$result['error'] = true; 
				$result['message'] = "Please select a product."; 
			}
			else
			{

				foreach ($_POST['p_id'] as $key) 
				{
					if ($_POST['qty'][$key] != 0) 
					{
						if ($_POST['t_amountgave'] < $_POST['t_total'] && $_POST['is_delivery'] == 0) 
						{ 
							$result['error'] = true; 
							$result['message'] = "Amount gave is less than total amount."; 
						}
						else
						{
							if ($_POST['c_id'] == 0 && trim($_POST['t_customer']) == "" && $_POST['is_delivery'] == 1) 
							{ 
								$result['error'] = true; 
								$result['message'] = "Customer required for delivery."; 
							}
						}

						$pData = $this->crud->getData("tbl_products", "p_id = $key")['rows'][0];

						array_push(
							$items, 
							array(
								"p_id"=>$key,
								"price"=>$pData->p_price,
								"qty"=>$_POST['qty'][$key]
							)
						);
					}

				}

			}
		}


		if ($result['error'] == false) 
		{
			$user_id = $_POST['user_id'];
			// unset($_POST['user_id']);

			unset($_POST['p_id']);
			unset($_POST['qty']);

			$add = $this->crud->addData("tbl_transactions", $_POST);

			foreach ($items as $key) 
			{
				$key['t_id'] = $add['ret_id'];

				$this->crud->addData("tbl_transaction_items", $key);
			}

			$this->crud->addData("tbl_logs", 
				array(
					"user_id"=>$user_id,
					"log_date"=>date("Y-m-d H:i:s"),
					"log_remarks"=>"add-$add[ret_id]-tbl_transactions",
				)
			);
		}

		echo json_encode($result);
	}
}