--REPLACE THE FOLLOWING --

VIEWS
	transactions
	printReceipt

CONTROLLERS
	transactions
	printReceipt

-- RUN THE CODE BELOW IN YOUR PHPMYADMIN --

ALTER TABLE `tbl_transaction_items` ADD `price` VARCHAR(255) NOT NULL AFTER `p_id`;


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `tbl_product_inventory` (
  `pi_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `pi_qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `tbl_product_inventory`
  ADD PRIMARY KEY (`pi_id`);

ALTER TABLE `tbl_product_inventory`
  MODIFY `pi_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;


----------------------------------------- NEW UPDATES -------------------------------------------

ALTER TABLE `tbl_product_inventory` CHANGE `pi_qty` `pi_item_code` VARCHAR(255) NOT NULL;
ALTER TABLE `tbl_product_inventory` ADD `pi_condition` VARCHAR(255) NULL DEFAULT 'Good' AFTER `pi_item_code`;

VIEWS
	products

CONTROLLERS
	products