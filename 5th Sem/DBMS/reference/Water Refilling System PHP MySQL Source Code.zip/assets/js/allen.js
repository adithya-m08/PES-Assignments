if (typeof (System) === "undefined") {
    System = {};
};

System.AllenJs = function System$AllenJs(page) {

	this.Initialize = function System$$Initialize() 
	{

    }

    this.validateForm = function System$validate$form(val)
    {
    	var success = true;
		var highlight = {"box-shadow" : "0 0 2px red", "border-color" : "red"};
		var removeHighlight = {"box-shadow" : "", "border-color" : ""};

		$('input[validation="' + val + '"], textarea[validation="' + val + '"], select[validation="' + val + '"]').each(function(){
			if ($(this).val() == "") 
			{
				$(this).css(highlight);//.attr("placeholder", "This field is required.");
				success = false;
			}
			else
			{
				$(this).css(removeHighlight);//.removeAttr("placeholder");
			}
		});

		return success;
    } 

    this.clearForm = function System$clear$form(val)
    {
		var removeHighlight = {"box-shadow" : "", "border-color" : ""};

		$('input[validation="' + val + '"], textarea[validation="' + val + '"], select[validation="' + val + '"]').val("").css(removeHighlight).removeAttr("placeholder");
	}

	this.paginate = function System$paginate(offset, table, otherData, controller)
	{
		var limit = $('#'+table+'-limit').val();
		var search = $('#'+table+'-search').val();

		$('#'+table+'-list-result').html('<tr><td colspan="100"><h2><i class="fa fa-spinner fa-spin"></i> Please wait...</h2></td></tr>');

		$.post(controller, {

			offset : offset,
			limit : limit,
			search : search,
			otherData : otherData

        }, function(data){

        	// alert(data);

        	$('#'+table+'-list-result, #'+table+'-paginate').html('');

			var result = eval('('+data+')');

			result.data.forEach(function(entry) {
                                
				$.template(table, $('#'+table+'-tmpl'));

				$.tmpl(table, entry).appendTo('#'+table+'-list-result');

			});

			if (offset != 0) 
			{
				$('#'+table+'-paginate').append("<li><a style='cursor:pointer' onclick=\"codeblooded.paginate("+(parseInt(offset)-parseInt(limit))+", '"+table+"', '"+otherData+"', '"+controller+"');\">«</a></li>");
			}
			else
			{
				$('#'+table+'-paginate').append("<li class='disabled'><a>«</a></li>");
			}
			
			var currentpage = offset / $('#'+table+'-limit').val() + 1;

			$('#'+table+'-page-'+currentpage).addClass("active");

			if (currentpage != parseInt(result.totalpages) && parseInt(result.totalpages) != 0) 
			{
				$('#'+table+'-paginate').append("<li><a style='cursor:pointer' onclick=\"codeblooded.paginate("+(parseInt(offset)+parseInt(limit))+", '"+table+"', '"+otherData+"', '"+controller+"');\">»</a></li>");
			}
			else
			{
				$('#'+table+'-paginate').append("<li class='disabled'><a>»</a></li>");
			}

			$('#'+table+'-label').html(result.label);

		});
	}

	this.addData = function System$add$data(id, btn)
	{
		var $this = new System.AllenJs();

		if (!$this.validateForm(id)) 
		{
			return;
		}

		$('#'+btn).html("<i class='fa fa-spinner fa-spin'></i>");

		$.post('allen/addData', 

			$('#'+id).serialize()

		, function(data){

			// alert(data);

			$this.clearForm(id);
			$this.clearForm('clear-me-please');

			noty({
                text: "Added successfully.",
                layout: 'topRight',
                type : "success"
            })

            $('#'+btn).html("Submit");

			setTimeout(function(){
            	$.noty.closeAll();
			},3000)

		});
	}

	this.editData = function System$edit$data(id, btn)
	{
		var $this = new System.AllenJs();

		if (!$this.validateForm(id)) 
		{
			return;
		}

		$('#'+btn).html("<i class='fa fa-spinner fa-spin'></i>");

		$.post('allen/editData', 

			$('#'+id).serialize()

		, function(data){

			// alert(data);

			noty({
                text: "Updated successfully.",
                layout: 'topRight',
                type : "success"
            })

            $('#'+btn).html("Save");

			setTimeout(function(){
            	$.noty.closeAll();
			},3000)

		});
	}

	this.deleteData = function System$deletedata(table, condition)
	{
		$.post('allen/deleteData',{ 

			table : table,
			condition : condition

		}, function(data){

			

		});
	}
}